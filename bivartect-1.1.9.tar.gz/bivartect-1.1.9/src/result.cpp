#include "result.hpp"
#include <iostream>
#include <fstream>
#include <ios>
#include <iosfwd>
#include <sstream>
#include <utility>
#include <iomanip>
#include <iterator>
#include <cmath>

using namespace std;

namespace result {

	// ---------------- Public ----------------

	MutationList::MutationList() {
		list_.reserve(1000);
	}

	MutationList::~MutationList() {
		list_.clear();
		list_.shrink_to_fit();
	}

	void MutationList::init(read::ReadCollection* readCollecion, uint8_t skipDepth, int sourceDivCount, bool bpMode) {
		reads_ = readCollecion;
		skipDepth_ = skipDepth;
		sourceDivCount_ = sourceDivCount;
		isBPasOthers_ = bpMode;
	}

	void MutationList::append(vector<MutationList::ReadInfo> normalReads, vector<MutationList::ReadInfo> mutationReads, uint16_t sourceDivNum)
	{
		lock_guard<mutex> lock(mtx_);
		if (normalReads.size() == 0) return;
		uint16_t index = normalReads[0].mutIndex - skipDepth_;
		uint64_t bases = reads_->fetchBases32At(normalReads[0].getSampleType(), normalReads[0].readID, index, skipDepth_, normalReads[0].getReadDirection());
		uint8_t bpBase = (uint8_t)(reads_->fetchBases32At(normalReads[0].getSampleType(), normalReads[0].readID, normalReads[0].mutIndex, 1, normalReads[0].getReadDirection()) >> 62);
		list_.emplace_back(RawMutationInfo{ bases, sourceDivNum, bpBase, normalReads, mutationReads });
	}

	void MutationList::optimize(bool isStrandSpecific)
	{
		combineDuplicates();
		createAllAvgReads();
		detectBreakpointTypes();
		set<uint32_t> omitList = omitLowQualityReads(breakpoints_);
		if (!isStrandSpecific) combineBothDirections(omitList);

		auto countTypes = [&](BreakpointType bpType) -> void {
			bpFoundCount_++;
			switch (bpType) {
			case BreakpointType::SNV:
				bpFoundCountDetail_[0]++;
				return;
			case BreakpointType::Others:
				if (isBPasOthers_) bpFoundCountDetail_[2]++;
				else bpFoundCountDetail_[1]++;
				return;
			default:
				bpFoundCountDetail_[1]++;
				return;
			}
		};
		for (int i = 0; i < (int)avgList_.size(); i++) {
			if (skipList_.count((uint32_t)i) > 0) continue;
			if (breakpoints_.main[i].exKey == UINT32_MAX) countTypes(breakpoints_.main[i].bpType);
			else {
				auto range = breakpoints_.extra.equal_range(breakpoints_.main[i].exKey);
				for (auto itr = range.first; itr != range.second; itr++) {
					countTypes(itr->second.bpType);
				}
			}
		}
	}

	std::string MutationList::overviewResult() const
	{
		auto calcRate = [](const vector<RawMutationInfo>& list, int index1, int index2, float &normalMatchRate, float &mutationMatchRate, int& normalCount, int& mutationCount) -> void {
			uint32_t ninn = 0; // predicted normal in normal sample
			uint32_t mint = 0; // predicted mutaion in tumor sample
			for (auto read : list[index1].predictedNormalReads) {
				if (read.getSampleType() == SampleType::Normal) {
					ninn++;
				}
			}
			for (auto read : list[index1].predictedMutatedReads) {
				if (read.getSampleType() == SampleType::Tumor) {
					mint++;
				}
			}
			uint32_t nsize = (uint32_t)list[index1].predictedNormalReads.size();
			uint32_t msize = (uint32_t)list[index1].predictedMutatedReads.size();
			if (index2 != index1) {
				for (auto read : list[index2].predictedNormalReads) {
					if (read.getSampleType() == SampleType::Normal) {
						ninn++;
					}
				}
				for (auto read : list[index2].predictedMutatedReads) {
					if (read.getSampleType() == SampleType::Tumor) {
						mint++;
					}
				}
				nsize += (uint32_t)list[index2].predictedNormalReads.size();
				msize += (uint32_t)list[index2].predictedMutatedReads.size();
			}
			uint32_t minn = (uint32_t)(msize - mint);
			uint32_t nint = (uint32_t)(nsize - ninn);
			normalMatchRate = (float)ninn / (ninn + minn);
			mutationMatchRate = (float)mint / (mint + nint);
			normalCount = nsize;
			mutationCount = msize;
		};

		string nrmStr, mutStr;
		stringstream sstr;
		sstr << "Found " << bpFoundCount_ << "(" << list_.size() << ") mutations.";
		sstr << " SNV:" << bpFoundCountDetail_[0] << " SV:" << bpFoundCountDetail_[1] << " BP:" << bpFoundCountDetail_[2] << "\n\n";
		int bpNumber = 1;
		for (int i = 0; i < (int)avgList_.size(); i++) {
			if (skipList_.count((uint32_t)i) > 0) {
				//sstr << "SKIP#" << i + 1 << " " << bpType2Str(breakpoints_.main[i].bpType) << "\n";
				//sstr << avgList_.normal[i].readStr << "\n\n";
				continue;
			}
			sstr << "#" << bpNumber++ << "\n";
			// rawMutInfo index
			int srci = avgList_.metas[i].rawListIndex1;
			int dsti = avgList_.metas[i].rawListIndex2;
			float nr, mr;
			int nc, mc;
			calcRate(list_, srci, dsti, nr, mr, nc, mc);
			sstr << "[Nrm] count:" << nc << " P:" << 100. * nr << "%  /  ";
			sstr << "[Mut] count:" << mc << " Q:" << 100. * mr << "%\n";
			/*sstr << "AvgQuality: " << 100. * avgList_.scores[i] << "%" << (avgList_.scores[i] < 0.5f ? "???ag" : "") << "  /  ";
			int ld = (int)ldAvg(avgList_.normal[i], avgList_.mutated[i], skipDepth_);
			sstr << "LD: " << ld << (ld > 4 ? "???ld" : "") << "\n";*/
			sstr << "BreakpointType: ";
			BreakpointInfo bpi = breakpoints_.main[i];
			if (bpi.exKey == UINT32_MAX) {
				sstr << bpType2Str(bpi.bpType) << " (" << bpi.before << " -> " << bpi.after << ")";
			}
			else {
				auto range = breakpoints_.extra.equal_range(bpi.exKey);
				for (auto itr = range.first; itr != range.second; itr++) {
					sstr << bpType2Str(itr->second.bpType) << " (" << itr->second.before << " -> " << itr->second.after << ") ";
				}
				sstr << " <== " << bpType2Str(bpi.bpType) << " (" << bpi.before << " -> " << bpi.after << ")";
			}
			sstr << "\n";

			uint16_t largestIndex = 0;
			for (auto item : list_[srci].predictedNormalReads) if (item.mutIndex > largestIndex) largestIndex = item.mutIndex;
			for (auto item : list_[srci].predictedMutatedReads) if (item.mutIndex > largestIndex) largestIndex = item.mutIndex;
			for (auto item : list_[dsti].predictedNormalReads) {
				int idx = reads_->getBaseCount(item.getSampleType(), item.readID) - item.mutIndex - 1;
				if (idx > largestIndex) largestIndex = (uint16_t)idx;
			}
			for (auto item : list_[srci].predictedMutatedReads) {
				int idx = reads_->getBaseCount(item.getSampleType(), item.readID) - item.mutIndex - 1;
				if (idx > largestIndex) largestIndex = (uint16_t)idx;
			}
			if (largestIndex < 3) largestIndex = 3;

			constexpr int prtBufSize = 256;
			char prtBuf[prtBufSize];

			snprintf(prtBuf, prtBufSize, "%*s!", 6 - 9 + largestIndex, "");
			sstr << "<Average>" << prtBuf << "\n";
			snprintf(prtBuf, prtBufSize, "%*s", 6 - 4 + largestIndex - avgList_.normal[i].mutIndex, "");
			sstr << "Nrm:" << prtBuf << avgList_.normal[i].readStr << "\n";
			snprintf(prtBuf, prtBufSize, "%*s", 6 - 4 + largestIndex - avgList_.mutated[i].mutIndex, "");
			sstr << "Mut:" << prtBuf << avgList_.mutated[i].readStr << "\n";

			snprintf(prtBuf, prtBufSize, "%*s!", 6 - 8 + largestIndex, "");
			sstr << "<Detail>" << prtBuf << "\n";

			//set<uint32_t> nIdList, mIdList;
			//set<uint32_t>* idLists[] = { &nIdList, &mIdList };
			const vector<ReadInfo>* readInfos[] = { &list_[srci].predictedNormalReads, &list_[srci].predictedMutatedReads };
			const vector<ReadInfo>* readInfos2[] = { &list_[dsti].predictedNormalReads, &list_[dsti].predictedMutatedReads };
			int16_t nmOffset[] = { avgList_.normal[i].combineOffset, avgList_.mutated[i].combineOffset };
			string str[] = { "Nrm", "Mut" };
			for (int j = 0; j < 2; j++) {
				for (int k = 0; k < (int)readInfos[j]->size(); k++) {
					const ReadInfo* readInfo = &readInfos[j]->at(k);
					//if (idLists[j]->count(readInfo->readID) > 0) continue;
					//idLists[j]->insert(readInfo->readID);
					snprintf(prtBuf, prtBufSize, "%*s", largestIndex - readInfo->mutIndex, "");
					sstr << str[j]
						<< (readInfo->getSampleType() == SampleType::Tumor ? "+" : "-")
						<< (readInfo->getReadDirection() == ReadDirection::Reverse ? "< " : "> ")
						<< prtBuf
						<< reads_->fetchReadString(readInfo->getSampleType(), readInfo->readID, sourceDivCount_ > 1, readInfo->getReadDirection()) << "\n";
				}
				if (srci != dsti) {
					for (int k = (int)readInfos2[j]->size() - 1; k >= 0; k--) {
						const ReadInfo* readInfo = &readInfos2[j]->at(k);
						//if (idLists[j]->count(readInfo->readID) > 0) continue;
						//idLists[j]->insert(readInfo->readID);
						string readStr = reads_->fetchReadString(readInfo->getSampleType(), readInfo->readID, sourceDivCount_ > 1, readInfo->getReadDirection() == ReadDirection::Forward ? ReadDirection::Reverse : ReadDirection::Forward);
						snprintf(prtBuf, prtBufSize, "%*s", (int)(largestIndex - (readStr.length() - readInfo->mutIndex - 1) + nmOffset[j]), "");
						sstr << str[j]
							<< (readInfo->getSampleType() == SampleType::Tumor ? "+" : "-")
							<< (readInfo->getReadDirection() == ReadDirection::Reverse ? "< " : "> ")
							<< prtBuf
							<< readStr
							<< ".\n";
					}
				}
			}

			snprintf(prtBuf, prtBufSize, "%*s^", 6 + largestIndex, "");
			sstr << prtBuf << "\n\n";
		}
		return move(sstr.str());
	}

	std::string MutationList::toFasta() const
	{
		string fasta = "";
		int id = 1;
		for (int i = 0; i < (int)avgList_.size(); i++) {
			if (skipList_.count((uint32_t)i) > 0) continue;
			BreakpointInfo bpi = breakpoints_.main[i];
			if (bpi.exKey == UINT32_MAX) {
				fasta += ">" + to_string(id++) + ":" + bpType2StrSV(bpi.bpType) + ":" + bpi.before + ":" + bpi.after + "\n";
				fasta += avgList_.normal[i].readStr.substr(0, avgList_.normal[i].mutIndex + bpi.offset) + "\n";
			}
			else {
				auto range = breakpoints_.extra.equal_range(bpi.exKey);
				for (auto itr = range.first; itr != range.second; itr++) {
					fasta += ">" + to_string(id++) + ":" + bpType2StrSV(itr->second.bpType) + ":" + itr->second.before + ":" + itr->second.after + "\n";
					fasta += avgList_.normal[i].readStr.substr(0, avgList_.normal[i].mutIndex + itr->second.offset) + "\n";
				}
			}
		}
		return fasta;
	}

	std::string MutationList::toFastq() const
	{
		string fastq = "";
		int id = 1;
		for (int i = 0; i < (int)avgList_.size(); i++) {
			if (skipList_.count((uint32_t)i) > 0) continue;
			BreakpointInfo bpi = breakpoints_.main[i];
			if (bpi.exKey == UINT32_MAX) {
				fastq += "@" + to_string(id++) + ":" + bpType2StrSV(bpi.bpType) + ":" + bpi.before + ":" + bpi.after + "\n";
				int len = avgList_.normal[i].mutIndex + bpi.offset;
				fastq += avgList_.normal[i].readStr.substr(0, len) + "\n+\n" + string(len, 'I') + "\n";
			}
			else {
				auto range = breakpoints_.extra.equal_range(bpi.exKey);
				for (auto itr = range.first; itr != range.second; itr++) {
					fastq += "@" + to_string(id++) + ":" + bpType2StrSV(itr->second.bpType) + ":" + itr->second.before + ":" + itr->second.after + "\n";
					int len = avgList_.normal[i].mutIndex + itr->second.offset;
					fastq += avgList_.normal[i].readStr.substr(0, len) + "\n+\n" + string(len, 'I') + "\n";
				}
			}
		}
		return fastq;
	}



	// ---------------- Private ----------------

	void MutationList::combineDuplicates() {
		if (list_.size() <= 1) return;

		// lambda
		/*auto stringToUi64 = [](string baseString) -> uint64_t {
		uint64_t res = 0;
		size_t len = baseString.length();
		if (len > 32) len = 32;
		for (int i = 0; i < len; i++) {
		res <<= 2;
		switch (baseString[i]) {
		case 'A':
		res |= baseA;
		break;
		case 'C':
		res |= baseC;
		break;
		case 'G':
		res |= baseG;
		break;
		case 'T':
		res |= baseT;
		break;
		default:
		break;
		}
		}
		return res << (64 - len * 2);
		};*/

		// 一時的に結果を格納するリスト
		vector<RawMutationInfo> newList;
		newList.reserve(list_.size() / 2);

		sort(list_.begin(), list_.end());

		uint64_t prevBase = 0;
		if (list_[0].commonBases == 0) prevBase = 1;

		if (sourceDivCount_ > 1 && newList.size() > 1) {
			// Div > 1のときはまだ旧仕様のまんま
			// 本当はitemの統合を和集合で行うべきだが、DivNumが1つに定まらなくなるので、旧仕様の唯一選択式のままにしてる
			// Divの運用をするときは要書き換え
			int prevDivNum = -1;
			for (auto item : list_) {
				if (item.commonBases != prevBase || item.sourceDivNum != prevDivNum) {
					prevBase = item.commonBases;
					prevDivNum = item.sourceDivNum;
					newList.push_back(item);
				}
			}
			int thresholdCount = (int)(sourceDivCount_ * sourceDivCount_ * MinSourceDivHitRate);
			auto vectorOmitDuplicate = [](vector<ReadInfo> list) -> vector<ReadInfo> {
				vector<ReadInfo> res;
				if (list.size() == 0) return res;
				res.reserve(list.size());
				uint32_t prevReadID = list[0].readID - 1;
				uint16_t prevMutIndex = 0;
				for (auto item : list) {
					if (prevReadID != item.readID || prevMutIndex != item.mutIndex) {
						res.push_back(item);
						prevReadID = item.readID;
						prevMutIndex = item.mutIndex;
					}
				}
				res.shrink_to_fit();
				return move(res);
			};

			list_.clear();
			list_.reserve(newList.size() / thresholdCount);
			prevBase = 0;
			if (newList[0].commonBases == 0) prevBase = 1;
			int listedGroupCount = 0;
			newList.push_back(RawMutationInfo{ newList.back().commonBases + 1, 0, 0xAB, vector<ReadInfo>(), vector<ReadInfo>() }); // sentinel
																															// newList is already sorted
			for (size_t i = 0; i < newList.size(); i++) {
				if (newList[i].commonBases != prevBase) {
					if (listedGroupCount >= thresholdCount) {
						vector<ReadInfo> normalReads, mutationReads;
						normalReads.reserve(100);
						mutationReads.reserve(100);
						for (size_t n = i - listedGroupCount; n < i; n++) {
							copy(newList[n].predictedNormalReads.begin(), newList[n].predictedNormalReads.end(), back_inserter(normalReads));
							copy(newList[n].predictedMutatedReads.begin(), newList[n].predictedMutatedReads.end(), back_inserter(mutationReads));
						}
						sort(normalReads.begin(), normalReads.end());
						sort(mutationReads.begin(), mutationReads.end());
						normalReads = vectorOmitDuplicate(normalReads);
						mutationReads = vectorOmitDuplicate(mutationReads);
						list_.push_back(RawMutationInfo{ newList[i - 1].commonBases, 0, 0xAB, normalReads, mutationReads });
					}
					listedGroupCount = 1;
					prevBase = newList[i].commonBases;
				}
				else {
					listedGroupCount++;
				}
			}
			list_.shrink_to_fit();
		}
		else {
			// Div == 1
			set<ReadInfo> nReadInfoSet, mReadInfoSet;
			prevBase = list_[0].commonBases;
			uint8_t prevBpBase = list_[0].bpBase;
			bool skip = false;
			for (auto item : list_) {
				if (item.commonBases == prevBase) {
					if (skip) continue;
					skip = (item.bpBase != prevBpBase);
				}
				else {
					// convert to vector<> from set<>
					if (!skip) {
						RawMutationInfo raw;
						raw.predictedNormalReads = vector<ReadInfo>(nReadInfoSet.begin(), nReadInfoSet.end());
						raw.predictedMutatedReads = vector<ReadInfo>(mReadInfoSet.begin(), mReadInfoSet.end());
						raw.commonBases = prevBase;
						raw.sourceDivNum = 0;
						newList.push_back(raw);
					}
					skip = false;
					// prepare for next
					prevBase = item.commonBases;
					nReadInfoSet.clear();
					mReadInfoSet.clear();
				}
				prevBpBase = item.bpBase;
				for (auto read : item.predictedNormalReads) {
					nReadInfoSet.insert(read);
				}
				for (auto read : item.predictedMutatedReads) {
					mReadInfoSet.insert(read);
				}
			}
			RawMutationInfo raw;
			raw.predictedNormalReads = vector<ReadInfo>(nReadInfoSet.begin(), nReadInfoSet.end());
			raw.predictedMutatedReads = vector<ReadInfo>(mReadInfoSet.begin(), mReadInfoSet.end());
			raw.commonBases = prevBase;
			raw.sourceDivNum = 0;
			newList.push_back(raw);

			list_ = move(newList);
			list_.shrink_to_fit();
		}
	}


	void MutationList::combineBothDirections(const std::set<uint32_t>& omitList)
	{
		skipList_ = ClusterIntegration::run(avgList_, breakpoints_, omitList);
	}

	uint8_t MutationList::levenshteinDistance(const std::string& read1, int targetIndex1, const std::string& read2, int targetIndex2)
	{
		int rightLen = (int)min(read1.length() - targetIndex1, read2.length() - targetIndex2);
		int leftLen = min(targetIndex1, targetIndex2);
		if (rightLen <= 0 || leftLen < 0) return 0;
		int allLen = rightLen + leftLen;
		int offset1 = targetIndex1 - leftLen;
		int offset2 = targetIndex2 - leftLen;

		constexpr int SIZE = 256; // Max 256
		// input read length must be smaller than 256, since type(LD) is uint8 and largest LD(255) is equal to the length of input read.
		if (allLen > SIZE - 1) allLen = SIZE - 1;
		uint8_t col[SIZE], prevCol[SIZE];

		for (int i = 0; i < allLen; i++) prevCol[i] = (uint8_t)i;
		for (int i = 0; i < allLen; i++) {
			col[0] = (uint8_t)(i + 1);
			for (int j = 0; j < allLen; j++) {
				col[j + 1] = (uint8_t)std::min({ prevCol[1 + j] + 1, col[j] + 1, prevCol[j] + (read1[offset1 + i] == read2[offset2 + j] ? 0 : 1) });
			}
			swap(col, prevCol);
		}
		return prevCol[allLen];
	}

	std::string MutationList::reverseReadString(std::string read) const
	{
		string str;
		str.reserve(read.length());
		for (int i = (int)read.length() - 1; i >= 0; i--) {
			switch (read[i])
			{
			case 'A':
				str.push_back('T');
				break;
			case 'C':
				str.push_back('G');
				break;
			case 'G':
				str.push_back('C');
				break;
			case 'T':
				str.push_back('A');
				break;
			default:
				str.push_back('N');
				break;
			}
		}
		return str;
	}

	void MutationList::detectBreakpointTypes()
	{
		breakpoints_.clear();
		for (int i = 0; i < (int)avgList_.size(); i++) {
			detectBreakpointType(avgList_.normal[i], avgList_.mutated[i], breakpoints_, (uint32_t)i);
		}
	}

	std::set<uint32_t> MutationList::omitLowQualityReads(const BreakpointList& bps)
	{
		set<uint32_t> res;
		for (int i = 0; i < (int)avgList_.size(); i++) {
			float sc = avgList_.scores[i];
			int ld = (int)ldAvg(avgList_.normal[i], avgList_.mutated[i], skipDepth_);
			if (ld >= 10 || sc <= 0.3f) res.insert((uint32_t)i);
			else {
				switch (bps.main[i].bpType) {
				case BreakpointType::Complex:
				case BreakpointType::mSNV:
				case BreakpointType::Others:
					if (ld >= 6 || sc <= 0.5f) res.insert((uint32_t)i);
					break;
				default:
					break;
				}
			}
		}
		return res;
	}

	void MutationList::detectBreakpointType(const AvgRead & nAvg, const AvgRead & mAvg, BreakpointList& bps, uint32_t id)
	{
		auto str2ui64 = [](const string& strBases, uint16_t index, uint64_t& ui64Bases) -> uint16_t {
			uint8_t count = 0;
			uint64_t bases = 0;
			for (int i = index; i < (int)strBases.length(); i++) {
				count++;
				bases <<= 2;
				switch (strBases[i])
				{
				case 'A':
					bases |= baseA;
					break;
				case 'C':
					bases |= baseC;
					break;
				case 'G':
					bases |= baseG;
					break;
				case 'T':
					bases |= baseT;
					break;
				default:
					break;
				}
				if (count >= 32) break;
			}
			ui64Bases = bases << (64 - count * 2);
			return count + index;
		};
		auto str2ui16 = [](const string& strBases, uint16_t index, uint16_t& ui16Bases) -> uint16_t {
			uint8_t count = 0;
			uint16_t bases = 0;
			for (int i = index; i < (int)strBases.length(); i++) {
				count++;
				bases <<= 2;
				switch (strBases[i])
				{
				case 'A':
					bases |= baseA;
					break;
				case 'C':
					bases |= baseC;
					break;
				case 'G':
					bases |= baseG;
					break;
				case 'T':
					bases |= baseT;
					break;
				default:
					break;
				}
				if (count >= 8) break;
			}
			ui16Bases = bases << (16 - count * 2);
			return count + index;
		};
		auto countSame = [](const string& read1, const string& read2, int offset) -> int {
			// 1 GGCGATTCATACC
			// 2     ATTCATA
			//   <--> offset
			//  return 7
			int count = 0;
			int loop = min((int)read1.length() - offset, (int)read2.length());
			for (int i = 0; i < loop; i++) {
				if (read1[offset + i] == read2[i]) count++;
			}
			return count;
		};

		const string& nstr = nAvg.readStr;
		const string& mstr = mAvg.readStr;
		uint16_t nidx = nAvg.mutIndex;
		uint16_t midx = mAvg.mutIndex;
		uint16_t ntail = (uint16_t)(nstr.size() - nidx); // include bp base
		uint16_t mtail = (uint16_t)(mstr.size() - midx);
		if (bps.main.size() > id && bps.main[id].exKey != UINT32_MAX) {
			bps.extra.erase(bps.main[id].exKey);
			bps.main[id].exKey = UINT32_MAX;
		}
		uint16_t minTailLen = (uint16_t)min(ntail, mtail); // include bp base
		constexpr uint16_t matchMin = 3; // 0 < match <= 24
		constexpr int elongationMatchTh = 6; // if match length <= this value then request elongation

		if (minTailLen <= matchMin) {
			// too short to detect
			BreakpointInfo bp;
			bp.bpType = BreakpointType::Others;
			bp.before = nstr.substr(nidx, nstr.size() - nidx);
			bp.after = mstr.substr(midx, mstr.size() - midx);
			if (bps.main.size() <= id)bps.main.push_back(bp);
			else bps.main[id] = bp;
			return;
		}

		uint64_t nread, mread;
		uint16_t crrMatchMin = matchMin;
		int maxScore = 0;

		struct BpCandidate
		{
			BreakpointType bpType;
			uint16_t nSvLen;
			uint16_t mSvLen;
			uint16_t matchLen;
		};
		BpCandidate bpCandidate = BpCandidate{ BreakpointType::Others, 0, 0, 0 };
		auto calcMatchScore = [](int matchLen, int allLen) -> int {
			int sc = matchLen * 2 + 100 * matchLen / allLen;
			return (sc < 100) ? 0 : sc;
		};

		// INS
		uint16_t matchMax = (uint16_t)min((int)ntail, 24);
		uint64_t nmDiff = 0;
		str2ui64(nstr, nidx, nread);
		uint16_t mnxtidx = str2ui64(mstr, midx + 1, mread);
		int shiftCount = 0;
		for (int crrMTail = mtail - 1; crrMTail >= crrMatchMin; crrMTail--) {
			uint16_t crrMatchMax = min((uint16_t)crrMTail, matchMax);
			nmDiff = (nread ^ mread) >> (64 - crrMatchMax * 2);
			for (uint16_t match = crrMatchMax; match >= crrMatchMin; match--) {
				// ACGTAGGC
				// ACGGGTAGGC
				//    ^
				// TAGGC == TAGGC
				// INS
				if (nmDiff == 0) {
					// Matched
					uint16_t allLen = min(ntail, (uint16_t)crrMTail);
					int sc = calcMatchScore(match, min(allLen, matchMax));
					if (sc <= maxScore) break;
					maxScore = sc;
					//crrMatchMin = match;
					bpCandidate = BpCandidate{ BreakpointType::INS, 0, (uint16_t)(shiftCount + 1), match };
					break;
				}
				nmDiff >>= 2;
			}

			mread <<= 2;
			if (++shiftCount % 8 == 0) {
				uint16_t mread16 = 0;
				mnxtidx = str2ui16(mstr, mnxtidx, mread16);
				mread |= mread16;
			}
		}

		// DEL
		matchMax = (uint16_t)min((int)mtail, 24);
		str2ui64(mstr, midx, mread);
		uint16_t nnxtidx = str2ui64(nstr, nidx + 1, nread);
		shiftCount = 0;
		for (int crrNTail = ntail - 1; crrNTail >= crrMatchMin; crrNTail--) {
			uint16_t crrMatchMax = min((uint16_t)crrNTail, matchMax);
			nmDiff = (nread ^ mread) >> (64 - crrMatchMax * 2);
			for (uint16_t match = crrMatchMax; match >= crrMatchMin; match--) {
				if (nmDiff == 0) {
					// Matched
					uint16_t allLen = min(mtail, (uint16_t)crrNTail);
					int sc = calcMatchScore(match, min(allLen, matchMax));
					if (sc <= maxScore) break;
					maxScore = sc;
					//crrMatchMin = match;
					bpCandidate = BpCandidate{ BreakpointType::DEL, (uint16_t)(shiftCount + 1), 0, match };
					break;
				}
				nmDiff >>= 2;
			}

			nread <<= 2;
			if (++shiftCount % 8 == 0) {
				uint16_t nread16 = 0;
				nnxtidx = str2ui16(nstr, nnxtidx, nread16);
				nread |= nread16;
			}
		}

		// SNV & INV & SNVSV
		matchMax = (uint16_t)24;
		int nShiftCount = 0;
		nnxtidx = str2ui64(nstr, nidx + 1, nread);
		for (int crrNTail = ntail - 1; crrNTail >= crrMatchMin; crrNTail--) {
			mnxtidx = str2ui64(mstr, midx + 1, mread);
			int mShiftCount = 0;
			for (int crrMTail = mtail - 1; crrMTail >= crrMatchMin; crrMTail--) {
				uint16_t crrMatchMax = min(min((uint16_t)crrMTail, (uint16_t)crrNTail), matchMax);
				nmDiff = (nread ^ mread) >> (64 - crrMatchMax * 2);
				for (uint16_t match = crrMatchMax; match >= crrMatchMin; match--) {
					if (nmDiff == 0) {
						// Matched
						//int dist = nShiftCount + mShiftCount + 2;
						//if (dist >= bpCandidate.nSvLen + bpCandidate.mSvLen) break;
						//if (crrMatchMin == match && (dist >= bpCandidate.nSvLen + bpCandidate.mSvLen)) break;
						//crrMatchMin = match;

						auto isCommonFound = [](BreakpointType bpType) -> bool {
							switch (bpType) {
							case BreakpointType::INS:
							case BreakpointType::DEL:
							case BreakpointType::SNV:
								return true;
							default:
								return false;
							}
						};

						BreakpointType bpt = BreakpointType::Complex;
						if (nShiftCount == mShiftCount) {
							if (nShiftCount == 0) bpt = BreakpointType::SNV;
							else {
								// INV or multi-SNV
								if (isCommonFound(bpCandidate.bpType)) break;
								uint16_t invLen = (uint16_t)(nShiftCount + 1);
								int ni = nidx - 1;
								int mi = midx + invLen;
								int loop = invLen;
								bool isMatched = false;
								while (--loop >= 0) {
									if (nstr[++ni] != mstr[--mi]) {
										isMatched = false;
										break;
									}
								}
								if (isMatched) {
									// INV
									bpt = BreakpointType::INV;
								}
								else {
									// mSNV
									bpt = BreakpointType::mSNV;
								}
							}
						}
						else {
							// Complex
							if (match < 6) break;
							if (isCommonFound(bpCandidate.bpType)) break;
						}

						int sc = calcMatchScore(match, min(min(crrNTail, crrMTail), (int)matchMax));
						if (sc <= maxScore) break;
						maxScore = sc;
						bpCandidate = BpCandidate{ bpt, (uint16_t)(nShiftCount + 1), (uint16_t)(mShiftCount + 1), match };
						break;
					}
					nmDiff >>= 2;
				}

				mread <<= 2;
				if (++mShiftCount % 8 == 0) {
					uint16_t mread16 = 0;
					mnxtidx = str2ui16(mstr, mnxtidx, mread16);
					mread |= mread16;
				}
			}

			nread <<= 2;
			if (++nShiftCount % 8 == 0) {
				uint16_t nread16 = 0;
				nnxtidx = str2ui16(nstr, nnxtidx, nread16);
				nread |= nread16;
			}
		}


		if (bpCandidate.bpType != BreakpointType::Others) {
			// quality is good enough
			BreakpointInfo bp;
			if (bpCandidate.matchLen <= elongationMatchTh) bp.needsElongation = true;
			if (bpCandidate.bpType == BreakpointType::SNV) {
				bp.bpType = BreakpointType::SNV;
				bp.before = nstr.substr(nidx, 1);
				bp.after = mstr.substr(midx, 1);
			}
			else if (bpCandidate.bpType == BreakpointType::INS) {
				bp.bpType = BreakpointType::INS;
				bp.before = "-";
				bp.after = mstr.substr(midx, bpCandidate.mSvLen);
			}
			else if (bpCandidate.bpType == BreakpointType::DEL) {
				bp.bpType = BreakpointType::DEL;
				bp.before = nstr.substr(nidx, bpCandidate.nSvLen);
				bp.after = "-";
			}
			else if (bpCandidate.bpType == BreakpointType::INV) {
				bp.bpType = BreakpointType::INV;
				bp.before = nstr.substr(nidx, bpCandidate.nSvLen);
				bp.after = mstr.substr(midx, bpCandidate.mSvLen);
			}
			else if (bpCandidate.bpType == BreakpointType::mSNV) {
				// if mmap contains the key(id) already, then this method erases it beforehand
				bp.before = nstr.substr(nidx, bpCandidate.nSvLen);
				bp.after = mstr.substr(midx, bpCandidate.mSvLen);
				int unmatchBaseCount = (int)bp.before.length() - countSame(bp.before, bp.after, 0);
				if (unmatchBaseCount <= 3) {
					// truly mSNV
					bp.bpType = BreakpointType::mSNV;
					bp.exKey = id;
					bp.needsElongation = true;

					for (int i = 0; i < (int)bp.before.length(); i++) {
						if (bp.before[i] != bp.after[i]) {
							BreakpointInfo bp2;
							bp2.bpType = BreakpointType::SNV;
							bp2.before = bp.before.substr(i, 1);
							bp2.after = bp.after.substr(i, 1);
							bp2.offset = (uint16_t)i;
							bps.extra.insert(make_pair(id, bp2));
						}
					}
				}
				else {
					// too many SNV for mSNV
					bp.bpType = BreakpointType::Others;
					bp.before = nstr.length() > nidx ? nstr.substr(nidx, nstr.length() - nidx) : "-";
					bp.after = mstr.length() > midx ? mstr.substr(midx, mstr.length() - midx) : "-";
				}
			}
			else {
				// Complex
				bp.bpType = BreakpointType::Complex;
				bp.before = nstr.substr(nidx, bpCandidate.nSvLen);
				bp.after = mstr.substr(midx, bpCandidate.mSvLen);
				bp.exKey = id;
				bp.needsElongation = true;

				BreakpointInfo bpSV;
				string shorter, longer;
				if (bpCandidate.nSvLen > bpCandidate.mSvLen) {
					// DEL
					bpSV.bpType = BreakpointType::DEL;
					longer = bp.before;
					shorter = bp.after;
				}
				else {
					// INS
					bpSV.bpType = BreakpointType::INS;
					shorter = bp.before;
					longer = bp.after;
				}

				if (shorter.length() == 1) {
					// A
					// CGAT
					// => SNV(A->C) + INS(->GAT)
					BreakpointInfo bpSNV;
					bpSNV.bpType = BreakpointType::SNV;
					bpSNV.before = bp.before.substr(0, 1);
					bpSNV.after = bp.after.substr(0, 1);
					bps.extra.insert(make_pair(id, bpSNV));

					if (bpSV.bpType == BreakpointType::INS) {
						bpSV.before = "-";
						bpSV.after = bp.after.substr(1, bp.after.length() - 1);
					}
					else {
						bpSV.before = bp.before.substr(1, bp.before.length() - 1);
						bpSV.after = "-";
					}
					bpSV.offset = 1;
					bps.extra.insert(make_pair(id, bpSV));
				}
				else {
					// ATT
					// CTTGA
					// => SNV(A->C) + INS(->GA)
					// 決め打ち感は否めない
					int diff = (int)longer.length() - (int)shorter.length();
					int mismatched = false;
					for (int i = 1; i < (int)shorter.length(); i++) {
						if (shorter[i] != longer[i]) {
							mismatched = true;
							break;
						}
					}
					if (!mismatched) {
						// case: SNV + SV
						BreakpointInfo bpSNV;
						bpSNV.bpType = BreakpointType::SNV;
						bpSNV.before = bp.before.substr(0, 1);
						bpSNV.after = bp.after.substr(0, 1);
						bps.extra.insert(make_pair(id, bpSNV));

						if (bpSV.bpType == BreakpointType::INS) {
							bpSV.before = "-";
							bpSV.after = bp.after.substr(shorter.length(), diff);
						}
						else {
							bpSV.before = bp.before.substr(shorter.length(), diff);
							bpSV.after = "-";
						}
						bpSV.offset = (uint16_t)shorter.length();
						bps.extra.insert(make_pair(id, bpSV));
					}
					else {
						mismatched = false;
						for (int i = 0; i < (int)shorter.length() - 1; i++) {
							if (shorter[i] != longer[diff + i]) {
								mismatched = true;
								break;
							}
						}
						if (!mismatched) {
							// case: SV + SNV
							BreakpointInfo bpSNV;
							bpSNV.bpType = BreakpointType::SNV;
							bpSNV.before = bp.before.substr(bp.before.length() - 1, 1);
							bpSNV.after = bp.after.substr(bp.after.length() - 1, 1);
							bpSNV.offset = (uint16_t)((int)bp.before.length() - 1);
							bps.extra.insert(make_pair(id, bpSNV));

							if (bpSV.bpType == BreakpointType::INS) {
								bpSV.before = "-";
								bpSV.after = bp.after.substr(0, diff);
							}
							else {
								bpSV.before = bp.before.substr(0, diff);
								bpSV.after = "-";
							}
							bps.extra.insert(make_pair(id, bpSV));
						}
						else {
							// unknown
							//bp.bpType = BreakpointType::Others;
							//bp.exKey = UINT32_MAX;
							bpSV.bpType = BreakpointType::Others;
							bpSV.before = bp.before;
							bpSV.after = bp.after;
							bps.extra.insert(make_pair(id, bpSV));
						}
					}
				}
			}
			if (bps.main.size() <= id) bps.main.push_back(bp);
			else bps.main[id] = bp;
			return;
		}
		// Others
		BreakpointInfo bp;
		bp.bpType = BreakpointType::Others;
		bp.before = nstr.length() > nidx ? nstr.substr(nidx, nstr.length() - nidx) : "-";
		bp.after = mstr.length() > midx ? mstr.substr(midx, mstr.length() - midx) : "-";
		bp.needsElongation = true;
		if (bps.main.size() <= id) bps.main.push_back(bp);
		else bps.main[id] = bp;
	}


	void MutationList::createAllAvgReads()
	{
		avgList_.clear();
		for (size_t i = 0; i < list_.size(); i++) {
			sort(list_[i].predictedNormalReads.begin(), list_[i].predictedNormalReads.end(), [](const ReadInfo& a, const ReadInfo& b) {return a.mutIndex > b.mutIndex; });
			sort(list_[i].predictedMutatedReads.begin(), list_[i].predictedMutatedReads.end(), [](const ReadInfo& a, const ReadInfo& b) {return a.mutIndex > b.mutIndex; });
			AvgRead nAvg, mAvg;
			float nScore = createAvgRead(list_[i].predictedNormalReads, nAvg);
			float mScore = createAvgRead(list_[i].predictedMutatedReads, mAvg);
			avgList_.push_back(nAvg, mAvg, AvgReadMeta{ (uint32_t)i , (uint32_t)i }, min(nScore, mScore));
		}
	}

	float MutationList::createAvgRead(vector<ReadInfo> group, MutationList::AvgRead& avg) const
	{
		uint16_t largestHeadLength = 0, longestTailLength = 0;
		for (auto item : group) {
			uint16_t head = item.mutIndex;
			uint16_t tail = reads_->getBaseCount(item.getSampleType(), item.readID) - item.mutIndex - 1;
			if (head > largestHeadLength) largestHeadLength = head;
			if (tail > longestTailLength) longestTailLength = tail;
		}
		// [Normal]
		//        !
		// ACGGGTAGCCA
		//   GGGTAGCCAAT
		//     GTAGCCAATGT
		// <----->          largestHeadLength
		//         <----->  longestTailLength
		constexpr char emptyMark = ' '; // must be smaller than ASCII 'A'
		vector<string> strReads;
		strReads.reserve(group.size());
		for (auto item : group) {
			string str = "";
			uint16_t head = item.mutIndex;
			for (int i = largestHeadLength - head; i > 0; i--) str += emptyMark;
			string r = reads_->fetchReadString(item.getSampleType(), item.readID, sourceDivCount_ > 1, item.getReadDirection());
			str += r;
			for (int i = longestTailLength + head + 1 - (int)r.size(); i > 0; i--) str += emptyMark;
			strReads.push_back(str);
		}
		vector<string> formarStrs;
		formarStrs.resize(group.size());
		vector<string> latterStrs;
		latterStrs.resize(group.size());
		for (int i = 0; i < (int)strReads.size(); i++) {
			string formar = strReads[i].substr(0, largestHeadLength);
			reverse(formar.begin(), formar.end());
			formarStrs[i] = formar;
			latterStrs[i] = strReads[i].substr(largestHeadLength, longestTailLength + 1);
		}
		sort(formarStrs.begin(), formarStrs.end());
		sort(latterStrs.begin(), latterStrs.end());
		string formarAvg, latterAvg;
		float formarScore, latterScore;
		formarScore = selectAvgBase(formarStrs.begin(), formarStrs.end(), 0, largestHeadLength - 1, false, formarAvg);
		formarAvg = formarAvg.substr(0, formarAvg.find_first_of(emptyMark, 0));
		reverse(formarAvg.begin(), formarAvg.end());
		latterScore = selectAvgBase(latterStrs.begin(), latterStrs.end(), 0, longestTailLength, true, latterAvg);
		latterAvg = latterAvg.substr(0, latterAvg.find_first_of(emptyMark, 0));
		avg.readStr = formarAvg + latterAvg;
		avg.mutIndex = (uint16_t)formarAvg.size();
		return formarScore * latterScore;
	}

	float MutationList::selectAvgBase(vector<string>::iterator begin, vector<string>::iterator end, uint16_t targetIndex, uint16_t endIndex, bool longer, string& resStr) const
	{
		vector<string>::iterator acgtBeginPtr[4];
		uint16_t acgt[4] = { 0, 0, 0, 0 };
		int foundBaseTypes = 0;
		uint8_t prevBase = baseNull;
		float score = 1;
		int emptyCount = 0;
		auto target = begin;
		while (target < end) {
			switch (target->at(targetIndex))
			{
			case 'A':
				if (prevBase != baseA) {
					prevBase = baseA;
					acgtBeginPtr[0] = target;
					foundBaseTypes++;
				}
				acgt[0]++;
				break;

			case 'C':
				if (prevBase != baseC) {
					prevBase = baseC;
					acgtBeginPtr[1] = target;
					foundBaseTypes++;
				}
				acgt[1]++;
				break;

			case 'G':
				if (prevBase != baseG) {
					prevBase = baseG;
					acgtBeginPtr[2] = target;
					foundBaseTypes++;
				}
				acgt[2]++;
				break;

			case 'T':
				if (prevBase != baseT) {
					prevBase = baseT;
					acgtBeginPtr[3] = target;
					foundBaseTypes++;
				}
				acgt[3]++;
				break;

			default:
				emptyCount++;
				break;
			}
			target++;
		}

		uint16_t largest;
		int selectedCharIndex;
		if (foundBaseTypes == 1) {
			// if there is no branch (most cases)
			largest = acgt[prevBase];
			selectedCharIndex = prevBase;
		}
		else if (foundBaseTypes == 0) {
			// end of read
			resStr = begin->substr(0, targetIndex);
			return 1;
		}
		else {
			uint16_t acgtBackup[4];
			int count = 0;
			for (int i = 0; i < 4; i++) {
				count += acgt[i];
				acgtBackup[i] = acgt[i];
			}
			sort(acgt, acgt + 4);
			largest = acgt[3];
			for (selectedCharIndex = 0; selectedCharIndex < 4; selectedCharIndex++) {
				if (largest == acgtBackup[selectedCharIndex]) break;
			}

			uint16_t secondLargest = acgt[2];
			if (secondLargest > 2) score = (float)(largest + emptyCount) / (count + emptyCount);

			if (largest == secondLargest) {
				// contains two or more largest values
				resStr = begin->substr(0, targetIndex);
				return score;
			}
		}

		if (largest == 1) {
			// last 1 read
			if (longer) resStr = *acgtBeginPtr[selectedCharIndex];
			else resStr = acgtBeginPtr[selectedCharIndex]->substr(0, targetIndex);
			return 1;
		}
		else {
			if (targetIndex >= endIndex) {
				// end of read
				resStr = *acgtBeginPtr[selectedCharIndex];
				return 1;
			}
			else {
				// continue
				return score * selectAvgBase(acgtBeginPtr[selectedCharIndex], acgtBeginPtr[selectedCharIndex] + largest, ++targetIndex, endIndex, longer, resStr);
			}
		}
	}

	std::string MutationList::u64toString(uint64_t bases, int length) const
	{
		string str = "";
		for (int i = 0; i < length; i++) {
			str += baseStrs[bases >> 62];
			bases <<= 2;
		}
		return str;
	}





	// ********** ClusterIntegration **********


	std::set<uint32_t> ClusterIntegration::run(result::MutationList::AvgReadVector& avgs, result::MutationList::BreakpointList& bps, const std::set<uint32_t>& omitList)
	{
		set<uint32_t> dupListSNV, dupListSV, resSkipList;
		vector<ngSNV> nFwds, mFwds, nSortRevs, mSortRevs;
		auto nAvgs = &avgs.normal;
		auto mAvgs = &avgs.mutated;
		createSNVngs(*nAvgs, nFwds, nSortRevs);
		createSNVngs(*mAvgs, mFwds, mSortRevs);
		for (uint32_t i = 0; i < (uint32_t)nAvgs->size(); i++) {
			// size() of nfwd, mfwd, navg and mavg is the same. size() of nrev or mrev is <= those
			if (omitList.count(i) > 0) continue;
			indexPair nPair, mPair;
			uint32_t nid = searchSNVPair(nSortRevs, *nAvgs, nFwds[i], dupListSNV, nPair);
			if (nid == UINT32_MAX) continue;
			uint32_t mid = searchSNVPair(mSortRevs, *mAvgs, mFwds[i], dupListSNV, mPair);
			if (mid == UINT32_MAX) continue;
			if (nid != mid) continue;
			// SNV
			if (bps.main[i].bpType != MutationList::BreakpointType::SNV || bps.main[nid].bpType != MutationList::BreakpointType::SNV) continue;
			dupListSNV.insert(i);
			dupListSNV.insert(nid);
			resSkipList.insert(nid);
			updateAvgList(*nAvgs, i, nid, nPair);
			updateAvgList(*mAvgs, i, nid, mPair);
			avgs.metas[i].rawListIndex1 = i;
			avgs.metas[i].rawListIndex2 = nid;
			nAvgs->at(i).combineOffset = 0;
			mAvgs->at(i).combineOffset = 0;
		}

		auto getMatchStartIndex = [](const string& fwd, const string& rev, indexPair pair) {
			string fwd2 = reverseReadString(rev);
			int i1 = pair.srcIndex;
			int i2 = (int)rev.length() - pair.destIndex - 1;
			int loop = min(i1, i2);
			while (loop-- > 0) {
				if (fwd[--i1] != fwd2[--i2]) {
					i1++;
					break;
				}
			}
			return i1;
		};

		auto nTrim = createTrimmedAvgs(*nAvgs, bps, omitList);
		auto mTrim = createTrimmedAvgs(*mAvgs, bps, omitList);
		auto nSVmap = createSVngs(nTrim);
		auto mSVmap = createSVngs(mTrim);
		int trimIndex = -1;
		for (uint32_t i = 0; i < (uint32_t)avgs.size(); i++) {
			if (bps.main[i].bpType == MutationList::BreakpointType::SNV) continue;
			if (omitList.count(i) > 0) continue;
			trimIndex++;
			if (dupListSV.count(i) > 0) continue;
			indexPair nPair, mPair;
			uint32_t nid = searchSVPair(nSVmap, *nAvgs, nTrim[trimIndex], dupListSV, nPair);
			uint32_t mid = searchSVPair(mSVmap, *mAvgs, mTrim[trimIndex], dupListSV, mPair);
			if (nid == UINT32_MAX && mid == UINT32_MAX) continue;
			if (nid != UINT32_MAX && mid != UINT32_MAX && nid != mid) continue;
			uint32_t nmid = min(nid, mid);
			int nMatchLen, mMatchLen;
			if (nid != UINT32_MAX) {
				nMatchLen = updateLongestMatch(nAvgs->at(i).readStr, nAvgs->at(nid).readStr, nPair);
				if (nMatchLen <= 0) continue;
			}
			else {
				nMatchLen = searchLongestMatch(nAvgs->at(i).readStr, nAvgs->at(nmid).readStr, nPair);
				if (nMatchLen > 0) {
					nid = nmid;
					if (nPair.srcIndex == 0 && nAvgs->at(i).mutIndex >= nPair.destIndex + 1) continue;
				}
			}
			if (mid != UINT32_MAX) {
				mMatchLen = updateLongestMatch(mAvgs->at(i).readStr, mAvgs->at(mid).readStr, mPair);
				if (mMatchLen <= 0) continue;
			}
			else {
				mMatchLen = searchLongestMatch(mAvgs->at(i).readStr, mAvgs->at(nmid).readStr, mPair);
				if (mMatchLen > 0) {
					mid = nmid;
					if (mPair.srcIndex == 0 && mAvgs->at(i).mutIndex >= mPair.destIndex + 1) continue;
				}
			}

			if (!bps.main[i].needsElongation || !bps.main[nmid].needsElongation) {
				if (nid == mid) {
					dupListSV.insert(i);
					dupListSV.insert(nmid);
					if (bps.main[i].needsElongation) resSkipList.insert(nmid);
					else resSkipList.insert(i);
				}
			}
			else {
				const string joint = "*";
				constexpr int matchLenThreshold = 12;
				if (nid == UINT32_MAX) {
					// only mutated is matched
					// large SV
					if (mMatchLen < matchLenThreshold) continue;
					int matchStartIndex = getMatchStartIndex(mAvgs->at(i).readStr, mAvgs->at(nmid).readStr, mPair);
					string matchStr = mAvgs->at(i).readStr.substr(matchStartIndex, mMatchLen);
					if (entropy3(matchStr) < 3.0f) continue;

					uint16_t muti2 = updateAvgList(*mAvgs, i, nmid, mPair);
					uint16_t muti1 = mAvgs->at(i).mutIndex;
					if (muti2 + 5 < muti1) continue;
					mAvgs->at(i).combineOffset = muti2 - mAvgs->at(i).mutIndex;
					nAvgs->at(i).combineOffset = (int16_t)((nAvgs->at(i).readStr.length() - nAvgs->at(i).mutIndex - 1) + joint.length() + (nAvgs->at(nmid).readStr.length() - nAvgs->at(nmid).mutIndex - 1) + 1);
					MutationList::BreakpointInfo bp;
					bp.before = nAvgs->at(i).readStr.substr(nAvgs->at(i).mutIndex, nAvgs->at(i).readStr.length() - nAvgs->at(i).mutIndex) + joint +
						reverseReadString(nAvgs->at(nmid).readStr.substr(nAvgs->at(nmid).mutIndex, nAvgs->at(nmid).readStr.length() - nAvgs->at(nmid).mutIndex));
					bp.after = (muti2 <= muti1 + 1) ? "-" : mAvgs->at(i).readStr.substr(muti1 + 1, muti2 - muti1 - 1);
					bp.bpType = MutationList::BreakpointType::DEL;
					bps.main[i] = bp;
					nAvgs->at(i).readStr += joint + reverseReadString(nAvgs->at(nmid).readStr);
				}
				else if (mid == UINT32_MAX) {
					// only normal is matched
					// large SV
					if (nMatchLen < matchLenThreshold) continue;
					int matchStartIndex = getMatchStartIndex(nAvgs->at(i).readStr, nAvgs->at(nmid).readStr, nPair);
					string matchStr = nAvgs->at(i).readStr.substr(matchStartIndex, nMatchLen);
					if (entropy3(matchStr) < 3.0f) continue;

					uint16_t muti2 = updateAvgList(*nAvgs, i, nmid, nPair);
					uint16_t muti1 = nAvgs->at(i).mutIndex;
					if (muti2 + 5 < muti1) continue;
					nAvgs->at(i).combineOffset = muti2 - nAvgs->at(i).mutIndex;
					mAvgs->at(i).combineOffset = (int16_t)((mAvgs->at(i).readStr.length() - mAvgs->at(i).mutIndex - 1) + joint.length() + (mAvgs->at(nmid).readStr.length() - mAvgs->at(nmid).mutIndex - 1) + 1);
					MutationList::BreakpointInfo bp;
					bp.before = (muti2 <= muti1 + 1) ? "-" : nAvgs->at(i).readStr.substr(muti1 + 1, muti2 - muti1 - 1);
					bp.after = mAvgs->at(i).readStr.substr(mAvgs->at(i).mutIndex, mAvgs->at(i).readStr.length() - mAvgs->at(i).mutIndex) + joint +
						reverseReadString(mAvgs->at(nmid).readStr.substr(mAvgs->at(nmid).mutIndex, mAvgs->at(nmid).readStr.length() - mAvgs->at(nmid).mutIndex));
					bp.bpType = MutationList::BreakpointType::INS;
					bps.main[i] = bp;
					mAvgs->at(i).readStr += joint + reverseReadString(mAvgs->at(nmid).readStr);
				}
				else {
					// both normal and mutated is matched
					// small SV
					uint16_t nmi = updateAvgList(*nAvgs, i, nmid, nPair);
					uint16_t mmi = updateAvgList(*mAvgs, i, nmid, mPair);
					nAvgs->at(i).combineOffset = (int16_t)nmi - nAvgs->at(i).mutIndex;
					mAvgs->at(i).combineOffset = (int16_t)mmi - mAvgs->at(i).mutIndex;
					MutationList::detectBreakpointType(nAvgs->at(i), mAvgs->at(i), bps, i);
					//bps.main[i].before += "!!!!!";/////
				}
				dupListSV.insert(i);
				dupListSV.insert(nmid);
				resSkipList.insert(nmid);
				avgs.metas[i].rawListIndex1 = i;
				avgs.metas[i].rawListIndex2 = nmid;
			}
		}

		// shrink avgs and reindex map
		/*map<uint32_t, MutationList::BreakpointInfo> resBP;
		vector<MutationList::AvgRead> nAvgs2, mAvgs2;
		vector<MutationList::AvgReadMeta> metas2;
		size_t size = (size_t)(nAvgs->size() - dupList.size() / 2);
		nAvgs2.reserve(size);
		mAvgs2.reserve(size);
		metas2.reserve(size);
		uint32_t newi = 0;
		for (uint32_t oldi = 0; oldi < (uint32_t)nAvgs->size(); oldi++) {
			if (nAvgs->at(oldi).readStr == "") continue;
			nAvgs2.push_back(nAvgs->at(oldi));
			mAvgs2.push_back(mAvgs->at(oldi));
			metas2.push_back(avgs.metas[oldi]);
			if (tempBP.count(oldi) > 0) {
				resBP.insert(make_pair(newi, tempBP.at(oldi)));
			}
			newi++;
		}
		avgs.normal = move(nAvgs2);
		avgs.mutated = move(mAvgs2);
		avgs.metas = move(metas2);*/
		for (auto item : omitList) resSkipList.insert(item);
		return move(resSkipList);
	}

	float ClusterIntegration::entropy3(const std::string & read)
	{
		uint8_t bases = 0;
		if (read.length() <= 3 || read.length() > UINT16_MAX) return 0;
		uint16_t counts[4 * 4 * 4];
		for (uint16_t& c : counts) c = 0;
		for (int i = 0; i < (int)read.length(); i++) {
			bases <<= 2;
			switch (read[i])
			{
			case 'A':
				bases |= baseA;
				break;
			case 'C':
				bases |= baseC;
				break;
			case 'G':
				bases |= baseG;
				break;
			case 'T':
				bases |= baseT;
				break;
			}
			if (i >= 2) {
				counts[bases & 0b00111111]++;
			}
		}
		float ent = 0;
		float all = (float)(read.length() - 2);
		for (int c : counts) {
			if (c == 0) continue;
			float p = c / all;
			ent += -p * log2(p);
		}
		return ent;
	}


	uint32_t ClusterIntegration::str2ui32(std::string b15)
	{
		uint32_t bases = 0;
		int i = 16;
		for (char b : b15) {
			i--;
			if (i < 0) return bases << 2;
			bases <<= 2;
			switch (b)
			{
			case 'A':
				bases |= baseA;
				break;
			case 'C':
				bases |= baseC;
				break;
			case 'G':
				bases |= baseG;
				break;
			case 'T':
				bases |= baseT;
				break;
			}
		}
		bases <<= (i * 2);
		return bases;
	}

	uint32_t ClusterIntegration::reverseUi32(uint32_t bases)
	{
		// AAG- => -CTT
		// swap per 2bits
		bases = ((bases & 0x0000FFFF) << 16) | ((bases >> 16) & 0x0000FFFF);
		bases = ((bases & 0x00FF00FF) << 8) | ((bases >> 8) & 0x00FF00FF);
		bases = ((bases & 0x0F0F0F0F) << 4) | ((bases >> 4) & 0x0F0F0F0F);
		bases = ((bases & 0x33333333) << 2) | ((bases >> 2) & 0x33333333);
		// reverse bits (A->T, C->G)
		return (~bases);
	}

	void ClusterIntegration::createSNVngs(const std::vector<result::MutationList::AvgRead>& avgs, std::vector<ngSNV>& fwdList, std::vector<ngSNV>& sortedRevList)
	{
		fwdList.reserve(avgs.size());
		sortedRevList.reserve(avgs.size());
		uint32_t id = 0;
		for (auto avg : avgs) {
			size_t tailLength = avg.readStr.length() - avg.mutIndex - 1;
			if (tailLength > 7) tailLength = 7;
			string b15str = avg.readStr.substr(avg.mutIndex - 7, 7 + 1 + tailLength);
			uint32_t b15ui32 = str2ui32(b15str);
			fwdList.push_back(ngSNV{ b15ui32, (uint8_t)b15str.length(), id });
			if (tailLength == 7) {
				sortedRevList.push_back(ngSNV{ reverseUi32(b15ui32) << 2, (uint8_t)15, id });
			}
			id++;
		}
		sort(sortedRevList.begin(), sortedRevList.end());
	}

	std::vector<ClusterIntegration::trimmedAvgInfo> ClusterIntegration::createTrimmedAvgs(const std::vector<result::MutationList::AvgRead>& avgs, const result::MutationList::BreakpointList& bps, const std::set<uint32_t>& omitList)
	{
		vector<trimmedAvgInfo> trims;
		int snvCount = 0;
		for (auto b : bps.main) {
			if (b.bpType == MutationList::BreakpointType::SNV) snvCount++;
		}
		trims.reserve(avgs.size() - snvCount);
		for (int i = 0; i < (int)avgs.size(); i++) {
			if (bps.main[i].bpType == MutationList::BreakpointType::SNV) continue;
			if (omitList.count((uint32_t)i) > 0) continue;
			auto avg = avgs[i];
			int startIndex = max(0, avg.mutIndex - 16);
			int subCount = (int)avg.readStr.size() - startIndex;
			if (subCount < svNgramLen) {
				trims.push_back(trimmedAvgInfo{ "", (uint32_t)i, 0 });
				continue;
			}
			string trimmed = avg.readStr.substr(startIndex, subCount);
			trims.push_back(trimmedAvgInfo{ trimmed, (uint32_t)i, (uint16_t)startIndex });
		}
		return move(trims);
	}

	std::multimap<uint32_t, ClusterIntegration::idIdx> ClusterIntegration::createSVngs(const std::vector<trimmedAvgInfo>& avgis)
	{
		multimap<uint32_t, idIdx> mmap;
		for (auto avgi : avgis) {
			uint32_t bases = 0;
			uint16_t si = avgi.trimStartIndex;
			for (int s = 0; s < (int)avgi.avgRead.length(); s++) {
				bases <<= 2;
				switch (avgi.avgRead[s])
				{
				case 'A':
					bases |= baseA;
					break;
				case 'C':
					bases |= baseC;
					break;
				case 'G':
					bases |= baseG;
					break;
				case 'T':
					bases |= baseT;
					break;
				}
				if (s >= svNgramLen - 1) {
					// multi-map allows to insert same valued keys
					mmap.insert(make_pair(bases & svNgramMask, idIdx{ avgi.id, (uint16_t)si }));
					si++;
				}
			}
		}
		return move(mmap);
	}
	std::string ClusterIntegration::reverseReadString(const std::string& read)
	{
		string str;
		str.reserve(read.length());
		for (int i = (int)read.length() - 1; i >= 0; i--) {
			switch (read[i])
			{
			case 'A':
				str.push_back('T');
				break;
			case 'C':
				str.push_back('G');
				break;
			case 'G':
				str.push_back('C');
				break;
			case 'T':
				str.push_back('A');
				break;
			default:
				str.push_back('N');
				break;
			}
		}
		return str;
	}

	float ClusterIntegration::calcOverlap(const std::string& read1, int targetIndex1, const std::string& read2, int targetIndex2)
	{
		//    *idx1->
		// CGAAAGA    read1
		//   AAAGATC  read2
		//    *idx2->
		string read2r = reverseReadString(read2);
		targetIndex2 = (int)read2.length() - targetIndex2 - 1;
		int rightLen = (int)min(read1.length() - targetIndex1, read2r.length() - targetIndex2);
		int leftLen = min(targetIndex1, targetIndex2);
		if (rightLen <= 0 || leftLen < 0) return 0;
		int allLen = rightLen + leftLen;
		if (allLen <= 4) return 0;
		int matchedCount = 0;
		int index1 = targetIndex1;
		int index2 = targetIndex2;
		for (int i = rightLen; i > 0; i--) {
			if (read1[index1++] == read2r[index2++]) matchedCount++;
			else break;
		}
		index1 = targetIndex1 - 1;
		index2 = targetIndex2 - 1;
		for (int i = leftLen; i > 0; i--) {
			if (read1[index1--] == read2r[index2--]) matchedCount++;
			else break;
		}
		return (float)matchedCount / allLen;
	}

	uint32_t ClusterIntegration::searchSNVPair(const std::vector<ngSNV>& sortedRevNgList, const std::vector<result::MutationList::AvgRead>& avgs, const ngSNV fwdTarget, const std::set<uint32_t>& dupList, indexPair & res)
	{
		if (dupList.count(fwdTarget.id) > 0) return UINT32_MAX;
		uint32_t mask = 0xFFFFFFFF << ((16 - fwdTarget.baseCount) * 2);
		// binary search
		auto itr = std::lower_bound(sortedRevNgList.begin(), sortedRevNgList.end(), fwdTarget, [](const ngSNV& a, const ngSNV& b) {return a.bases < b.bases; });
		while (itr != sortedRevNgList.end() && ((itr->bases & mask) == (fwdTarget.bases & mask))) {
			bool overlapped = checkOverlap(avgs[fwdTarget.id].readStr, avgs[fwdTarget.id].mutIndex, avgs[itr->id].readStr, avgs[itr->id].mutIndex);
			if (overlapped && dupList.count(itr->id) == 0 && fwdTarget.id != itr->id) {
				res = indexPair{ avgs[fwdTarget.id].mutIndex, avgs[itr->id].mutIndex };
				return itr->id;
			}
			else itr++;
		}
		return UINT32_MAX;
	}

	uint32_t ClusterIntegration::searchSVPair(const std::multimap<uint32_t, idIdx>& svmap, const std::vector<result::MutationList::AvgRead>& avgs, const trimmedAvgInfo avgi, const std::set<uint32_t>& dupList, indexPair& res)
	{
		if (avgi.avgRead == "") return UINT32_MAX;
		if (dupList.count(avgi.id) > 0) return UINT32_MAX;
		uint32_t bases = 0;
		uint16_t trimStartIndex = (uint16_t)(avgi.trimStartIndex + avgi.avgRead.length() - 1);
		static vector<uint64_t> skips; // to avoid overhead, create instance as static
		skips.clear();
		auto createSkipHash = [](uint32_t id, uint32_t index1, uint32_t index2) -> uint64_t {
			return ((uint64_t)id << 32) + (uint64_t)(index1 + index2);
		};
		// create reverse and compare
		for (int s = (int)avgi.avgRead.size() - 1; s >= 0; s--) {
			bases <<= 2;
			switch (avgi.avgRead[s])
			{
			case 'A':
				bases |= baseT;
				break;
			case 'C':
				bases |= baseG;
				break;
			case 'G':
				bases |= baseC;
				break;
			case 'T':
				bases |= baseA;
				break;
			}
			if (s <= (int)avgi.avgRead.size() - svNgramLen) {
				auto range = svmap.equal_range(bases & svNgramMask);
				for (auto itr = range.first; itr != range.second; itr++) {
					// may matched
					if (skips.size() > 0 && find(skips.begin(), skips.end(), createSkipHash(itr->second.id, itr->second.index, trimStartIndex)) != skips.end()) continue;
					if (dupList.count(itr->second.id) == 0 && avgi.id != itr->second.id && checkOverlap(avgs[avgi.id].readStr, trimStartIndex - svNgramLen + 1, avgs[itr->second.id].readStr, itr->second.index + svNgramLen - 1)) {
						// certainly matched 
						res = indexPair{ (uint16_t)(trimStartIndex - svNgramLen + 1), (uint16_t)(itr->second.index + svNgramLen - 1) };
						return itr->second.id;
					}
					else {
						// not matched
						skips.push_back(createSkipHash(itr->second.id, itr->second.index, trimStartIndex));
					}
				}
				trimStartIndex--;
			}
		}
		return UINT32_MAX;
	}

	uint16_t ClusterIntegration::uniteTwoAvgs(const result::MutationList::AvgRead& avg1, const result::MutationList::AvgRead& avg2, indexPair idxs, result::MutationList::AvgRead& newAvg)
	{
		string res;
		res.reserve(idxs.srcIndex + 1 + idxs.destIndex);
		string rev = reverseReadString(avg2.readStr);
		int revIndex = (int)rev.length() - idxs.destIndex - 1;
		for (int i = 0; i <= idxs.srcIndex; i++) res.push_back(avg1.readStr[i]);
		for (int i = revIndex + 1; i < (int)rev.length(); i++) res.push_back(rev[i]);
		newAvg.readStr = res;
		newAvg.mutIndex = avg1.mutIndex;
		return (uint16_t)(res.length() - avg2.mutIndex - 1);
	}

	uint16_t ClusterIntegration::updateAvgList(std::vector<result::MutationList::AvgRead>& avgs, uint32_t id1, uint32_t id2, indexPair idxs)
	{
		MutationList::AvgRead navg;
		uint16_t mutIndex2 = uniteTwoAvgs(avgs[id1], avgs[id2], idxs, navg);
		avgs[id1] = move(navg);
		return mutIndex2;
	}

	int ClusterIntegration::updateLongestMatch(const std::string & readFwd, const std::string & readRev, indexPair & idxs)
	{
		int revIndex = (int)readRev.length() - idxs.destIndex - 1;
		int oldDiff = idxs.srcIndex - revIndex;
		int newDiff;
		int count = findLongestMatch(readFwd, reverseReadString(readRev), newDiff);
		if ((int)readFwd.length() > newDiff + (int)readRev.length()) return -1;
		if (newDiff < oldDiff) idxs.srcIndex = (uint16_t)(idxs.srcIndex - (oldDiff - newDiff));
		return count;
	}

	int ClusterIntegration::searchLongestMatch(const std::string & readFwd, const std::string & readRev, indexPair& idxs)
	{
		constexpr int EnoughMatchCount = 12;
		int offset;
		string readFwd2 = reverseReadString(readRev);
		int count = findLongestMatch(readFwd, readFwd2, offset);
		if ((int)readFwd.length() > offset + (int)readRev.length()) return 0;
		if (count >= EnoughMatchCount) {
			idxs = indexPair{ (uint16_t)offset, (uint16_t)(readRev.length() - 1) };
			return count;
		}
		else {
			count = findLongestMatch(readFwd2, readFwd, offset);
			if (readFwd.length() > offset + readRev.length()) return 0;
			if (count >= EnoughMatchCount) {
				idxs = indexPair{ 0, (uint16_t)(readRev.length() - 1 - offset) };
				return count;
			}
			else return 0;
		}
	}

	int ClusterIntegration::findLongestMatch(const std::string & read1, const std::string & read2, int& offset)
	{
		auto countMatchBases = [](uint64_t readXor, int len) -> int {
			int count = 0;
			constexpr uint64_t mask = (uint64_t)0b11 << 62;
			while (len-- > 0) {
				if ((mask & readXor) == 0) {
					// match
					count++;
				}
				readXor <<= 2;
			}
			return count;
		};
		auto str2ui64 = [](const string& strBases, uint64_t& ui64Bases) -> int {
			int index = 0;
			uint64_t bases = 0;
			for (; index < (int)strBases.length(); index++) {
				bases <<= 2;
				switch (strBases[index])
				{
				case 'A':
					bases |= baseA;
					break;
				case 'C':
					bases |= baseC;
					break;
				case 'G':
					bases |= baseG;
					break;
				case 'T':
					bases |= baseT;
					break;
				default:
					break;
				}
				if (index == 31) break;
			}
			ui64Bases = bases << ((31 - index) * 2);
			return index + 1;
		};

		uint64_t rev64;
		int revLen64 = str2ui64(read2, rev64);

		uint64_t fwd64 = 0;
		int maxCount = 0, fwdIndexBackup = -1;
		for (int i = 0, fwdLen = (int)read1.length(); i < fwdLen + 32 - 8; i++) {
			fwd64 <<= 2;
			if (i < fwdLen) {
				switch (read1[i])
				{
				case 'A':
					fwd64 |= baseA;
					break;
				case 'C':
					fwd64 |= baseC;
					break;
				case 'G':
					fwd64 |= baseG;
					break;
				case 'T':
					fwd64 |= baseT;
					break;
				default:
					break;
				}
			}
			if (i >= 31) {
				int fwdIndex = i - 31;
				int fwdLen64 = min(32, fwdLen - fwdIndex);
				int xorLen = min(fwdLen64, revLen64);
				int count = countMatchBases(fwd64 ^ rev64, xorLen);
				float matchRate = (float)count / xorLen;
				if (count > maxCount && matchRate >= 0.92f) {
					maxCount = count;
					fwdIndexBackup = fwdIndex;
				}
				if (maxCount == 32) break;
				if (fwdLen64 <= maxCount) break;
			}
		}

		if (fwdIndexBackup >= 0) offset = fwdIndexBackup;
		return maxCount;
	}
}
