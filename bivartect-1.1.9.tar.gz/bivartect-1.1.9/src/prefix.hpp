#pragma once
#include <cstdlib>
#include <vector>
#include <string>
#include "base.hpp"
#include "read.hpp"
#include "result.hpp"

namespace result { class MutationList; }
namespace read { class ReadCollection; }

namespace prefix{

	// alignment is 4byte order
#pragma pack(8)
	class PrefixUnit{
		// PrefixUnitは解析の最小単位のオブジェクト。
		// 格納している情報は以下の通り
		// Bases(64)	最大32or29の塩基
		// ID(32)		このPrefixUnitが対象としているリード固有の番号
		// Offset(12)	PrefixUnitに最初に格納した塩基鎖がリード先頭から何塩基か
		// Index(16)	次に読むべきリード内座標。Fwdのときは前から、Revのときは後ろから数える
		// Sample(1)	Positive/Negative
		// Direct(1)	Forward/Reverse
	public:
		PrefixUnit();
		bool operator<(const PrefixUnit& right) const { return prefix_ < right.prefix_; }

		PrefixUnit(const PrefixUnit& other) {
			prefix_ = other.prefix_;
			id_ = other.id_;
			baseIndex_ = other.baseIndex_;
			baseOffsetL8_ = other.baseOffsetL8_;
			flags_ = other.flags_;
		}

		void init(uint32_t readID, uint16_t baseOffset, SampleType sampleType, ReadDirection direct);

		// You dont have to mind the validity of index as log as 0 <= localIndex < 29
		// Use this when prefix is 29base mode!!
		// return A,C,G,T or null
		Base getBaseAt(uint8_t localIndex) const;

		inline void setPrefix(uint64_t newPrefix, uint8_t prefixBaseCount) { prefix_ = newPrefix; baseIndex_ += prefixBaseCount; }
		inline uint64_t getPrefix() const { return prefix_; }
		inline uint32_t getID() const { return id_; }
		inline uint16_t getBaseIndex() const { return baseIndex_; }
		inline uint16_t getBaseOffset() const { return baseOffsetL8_ + ((uint16_t)(flags_ & 0x0F) << 8); }

		//inline bool isTumor() const { return (flags_ & uint8_t(0b00010000)) > 0; }
		inline SampleType getSampleType() const { return (flags_ & uint8_t(0b00010000)) ? SampleType::Tumor : SampleType::Normal; }
		inline ReadDirection getReadDirection() const { return (flags_ & uint8_t(0b00100000)) ? ReadDirection::Reverse : ReadDirection::Forward; }


	private:
		// ReadUnit
		//   [readBinary(2bit x baseCount as byte)(min 8byte)]
		// <1st step>
		//        [prefix(8byte)]
		//   |<-->| offset(never changed)
		//   |------------------>| index(change on prefix read frame shifts)
		// <2nd step>
		//                       [prefix(8byte)]
		//   |<-->| offset
		//   |--------------------------------->| index


		// read prefix as binary(64bit)
		uint64_t prefix_;

		// original read's ID (= ReadUnit object's index in vector)
		uint32_t id_;

		// original read's base index which read next time
		uint16_t baseIndex_;

		// first prefix offset
		// base length is restricted to 4095+skipDepth
		uint8_t baseOffsetL8_;

		// various flags + baseOffset_ higher 4bit
		// 0-3bit : baseOffset higher 4bit (in many cases (readLength < 255+skipDepth) these bits are not used)
		// 4bit : Sample type (0=Normal / 1=Tumor)
		// 5bit : Reversed or not (0=No / 1=Yes) 
		// 7bit : Quit deeper level search (0=No / 1=Yes)  NOT USED NOW
		uint8_t flags_;


		//inline void setIsTumor(bool flag) { flag ? flags_ |= uint8_t(0b00010000) : flags_ &= uint8_t(0b11101111); }
		inline void setSampleType(SampleType sampleType) { sampleType == SampleType::Tumor ? flags_ |= uint8_t(0b00010000) : flags_ &= uint8_t(0b11101111); }
		inline void setReadDirection(ReadDirection direct) { direct == ReadDirection::Reverse ? flags_ |= uint8_t(0b00100000) : flags_ &= uint8_t(0b11011111); }
	};
#pragma pack()


	class QuadInfo{
	public:
		QuadInfo();

		void load(PrefixUnit* first, PrefixUnit* last, uint8_t localIndex, uint16_t minHBaseCount, uint16_t minLBaseCount);

		// return IF (length<MinBaseCount) THEN false ELSE true
		bool getRange(Base base, PrefixUnit*& start, uint32_t& length);

		inline Base getNormalBase() { return normalBase; }

		enum class AnalyzeResult{
			Zero, // each kind of base's reads count came short of the threshold
			One, // only one kind of base's reads count exceeded the threshold
			ListedDiv, // found a significant mutation and listed (=divergence exists)
			ListedSuspDiv, // found a mutated base but couldn't find paired normal reads
			NotListedDiv // divergence exists, but the rate was less than the thleshold and not be considered as a mutation
		};

		// 後回し
		/*struct AnalyzeParameters
		{
			float ppppppppv;
		};*/

		AnalyzeResult analyze(uint16_t globalIndex, result::MutationList* mutList, float minMutationMatchRate, float maxMutationMatchRate, float minNormalMatchRate, bool isSingleEnd, uint16_t sourceDivNum);

	private:
		// A(All)-A(Mut)-C(All)-C(Mut)-G(All)-G(Mut)-T(All)-T(Mut)
		uint32_t counts_[8];
		// n addr
		PrefixUnit* startPtr_;
		// n
		// n+A
		// n+A+C
		// n+A+C+G
		// n+A+C+G+T
		uint32_t accumCounts_[5];
		// IF (one kind of base's Count(A or C or...)<MinBaseCount) THEN GetRange() return false and deeper search will be stopped
		uint16_t minHBaseCount_, minLBaseCount_;
		// when the result is appended to MutationList in analyze(), the base considered as normal is stored here
		Base normalBase;
		bool containsBothDirections_[4];


		// IF (MutCount/(Mut+NrmCount) >= ppv) THEN consider the base to be a mutation
		//float ppv_ = 0.9F;
		// IF (NrmCount/(Mut+NrmCount) >= npv_) THEN consider the base to be a normal
		//float npv_ = 0.9F;
		// if both of aboves are true, judge as mutation
	};


	class PrefixCollection{
	public:
		PrefixCollection();
		~PrefixCollection();

		// if skipDepth is larger than 32, loads following bases using this method till reaching skipDepth as 4b/B mode (length <= 32)
		//void loadNextBases(read::ReadCollection* reads, PrefixUnit* start, PrefixUnit* end, uint8_t length);

		// on finished loading skipDepth bits, load remain bases as 29b/8B mode
		void loadNext29Bases(read::ReadCollection* reads, PrefixUnit* first, PrefixUnit* last);

		// allocate memory
		bool newDictMemory(uint64_t dictSize);
		// (if exists) delete allocated memory
		// this is called automatically before newDictMemory() or in the destructor of PrefixCollection
		void deleteDictMemory();

		// append prefix to dictionary
		bool append(uint64_t prefix, uint8_t prefixBaseCount, uint32_t readID, uint16_t baseOffset, SampleType sampleType, ReadDirection direct);

		// sort dictionary
		void sort(PrefixUnit* first, PrefixUnit* last, uint16_t threadCount) const;

		// search objects which have the same prefix as "start" has in the dictionary descendingly, and return final object's pointer
		PrefixUnit* getSameRange(PrefixUnit* start) const;

		QuadInfo createQuadInfo(PrefixUnit* first, PrefixUnit* last, uint8_t localIndex, uint16_t minHBaseCount, uint16_t minLBaseCount);
		PrefixUnit* dictBeginPtr() const { return prefixDictionary_; }
		PrefixUnit* dictEndPtr() const { return (prefixDictionary_ + dictSize_ - 1); } // End addr is dict[len-1]. NOT dict[len]

		inline size_t consumingMemory() const { return dictSize_ * sizeof(PrefixUnit); }

	private:
		// copy constructor is prohibited
		PrefixCollection(const PrefixCollection&) = delete;
		void pSort(PrefixUnit* first, PrefixUnit* last, uint_fast8_t depth, uint_fast8_t maxDepth) const;
		void pMerge(const std::vector<PrefixUnit*>& reg) const;

		PrefixUnit* prefixDictionary_;
		const read::ReadCollection* readCollection_;
		uint64_t dictSize_;
		uint64_t dictIndex_;



#ifndef NDEBUG
	public:
		void _dumpDictionary(bool as29baseMode);
		static void _dumpDictionary(PrefixUnit* start, PrefixUnit* end, bool as29baseMode);
#endif
	};
}