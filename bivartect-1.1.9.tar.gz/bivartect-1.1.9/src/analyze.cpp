#include "analyze.hpp"
#include <thread>
#include <algorithm> // min
#include <iostream>

using namespace std;
using namespace read;
using namespace prefix;

namespace analyze {

	Analyze::Analyze() {
		skipDepth_ = 30;
		minHBaseCount_ = 6;
		minLBaseCount_ = 4;
		minNormalMatchRate_ = minMutationMatchRate_ = 0.8f;
		maxMutationMatchRate_ = 1.0f;
	}

	void Analyze::init(uint16_t skipDepth, uint16_t minHBaseCount, uint16_t minLBaseCount, float minMutationMatchRate, float maxMutationMatchRate, float minNormalMatchRate, bool needBothDirection, uint16_t threadCount) {
		skipDepth_ = skipDepth;
		minHBaseCount_ = minHBaseCount;
		minLBaseCount_ = minLBaseCount;
		minMutationMatchRate_ = minMutationMatchRate;
		maxMutationMatchRate_ = maxMutationMatchRate;
		minNormalMatchRate_ = minNormalMatchRate;
		needBothDirection_ = needBothDirection;
		threadCount_ = min<uint16_t>(threadCount == 0 ? (uint16_t)0xFFFF : threadCount, (uint16_t)thread::hardware_concurrency());
	}

	void Analyze::run(read::ReadCollection* reads, prefix::PrefixCollection* prefixs, result::MutationList* mutList, uint16_t sourceDivNum) {
		if (prefixs->dictBeginPtr() == nullptr) return;
		reads_ = reads;
		prefixs_ = prefixs;
		mutList_ = mutList;
		sourceDivNum_ = sourceDivNum;
		formar(prefixs_->dictBeginPtr(), prefixs_->dictEndPtr() + 1, skipDepth_);
	}


	void Analyze::formar(prefix::PrefixUnit * first, prefix::PrefixUnit * last, uint16_t remainSkipDepth) {
		prefixs_->sort(first, last, threadCount_);
		if (remainSkipDepth > 32) {
			// 1st step analyze didn't finish
			// repeat "store->sort->restrict_range" cycle.
			/*while (start <= end) {
				smallEnd = prefixs_->getSameRange(start);
				int len = remainSkipDepth - 32;
				prefixs_->loadNextBases(reads_, start, smallEnd, len > 32 ? 32 : (uint8_t)len);
				formar(start, smallEnd + 1, remainSkipDepth - 32);
				start = smallEnd + 1;
			}*/
			// 33以上はいいやって
			return;
		}
		else {
			// 1st step analyze finished
			auto div = (last - first) / threadCount_;
			if (threadCount_ == 1 || div < 100000) {
				// Non MT
				mtTask(first, last);
			}
			else {
				// MT
				vector<PrefixUnit*> region(threadCount_);
				region[0] = first;
				for (int i = 1; i < (int)region.size(); i++) {
					region[i] = prefixs_->getSameRange(first + i * div) + 1;
				}

				vector<thread> ths;
				ths.reserve(threadCount_ - 1);
				for (int i = 0; i < threadCount_ - 1; i++) {
					ths.push_back(thread(&Analyze::mtTask, this, region[i], region[i + 1]));
				}
				mtTask(region[region.size() - 1], last);

				for (auto& th : ths) if (th.joinable()) th.join();
			}
		}
	}

	void Analyze::mtTask(prefix::PrefixUnit * first, prefix::PrefixUnit * last) {
		PrefixUnit* smallEnd;
		while (first < last) {
			smallEnd = prefixs_->getSameRange(first) + 1;
			// go to 2nd step analyze
			latter(first, smallEnd, 29, skipDepth_);
			first = smallEnd;
		}
	}

	void Analyze::latter(prefix::PrefixUnit * first, prefix::PrefixUnit * last, uint8_t localIndex, uint16_t globalIndex) {
		if (localIndex == 29) {
			prefixs_->loadNext29Bases(reads_, first, last);
			prefixs_->sort(first, last, 1);
			localIndex = 0;
		}
		QuadInfo qinfo = prefixs_->createQuadInfo(first, last, localIndex, minHBaseCount_, minLBaseCount_);
		switch (qinfo.analyze(globalIndex, mutList_, minMutationMatchRate_, maxMutationMatchRate_, minNormalMatchRate_, needBothDirection_, sourceDivNum_)) {
		case QuadInfo::AnalyzeResult::One:
		case QuadInfo::AnalyzeResult::NotListedDiv:
			// continue search
			localIndex++;
			globalIndex++;
			PrefixUnit* smallStart;
			uint32_t smallLength;
			for (uint8_t i = 0; i < 4; i++) {
				if (qinfo.getRange((Base)i, smallStart, smallLength)) {
					// if the range has enough length, continue
					latter(smallStart, smallStart + smallLength, localIndex, globalIndex);
				}
			}
			return;
		case QuadInfo::AnalyzeResult::ListedDiv:
		case QuadInfo::AnalyzeResult::ListedSuspDiv:
			// continue search
			localIndex++;
			globalIndex++;
			PrefixUnit* normalStart;
			uint32_t normalLength;
			if (qinfo.getRange(qinfo.getNormalBase(), normalStart, normalLength)) {
				// if the range has enough length, continue
				latter(normalStart, normalStart + normalLength, localIndex, globalIndex);
			}
			return;
		default:
			// quit deeper search
			return;
		}
	}
}