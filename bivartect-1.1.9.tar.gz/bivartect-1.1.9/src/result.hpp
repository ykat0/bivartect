#pragma once
#include <cstdlib>
#include <vector>
#include <string>
#include <mutex>
#include <algorithm>
#include <map>
#include <set>
#include "base.hpp"
#include "read.hpp"
#include "prefix.hpp"

namespace read { class ReadCollection; }
namespace prefix { class PrefixUnit; }

namespace result {
#pragma pack(8)
	class MutationList {
	public:
		MutationList();
		~MutationList();

		struct ReadInfo {
			uint32_t readID;
			uint16_t mutIndex;
			uint8_t flags;
			inline void setFlags(SampleType sampleType, JudgedType judgedType, ReadDirection direct) {
				flags = 0;
				sampleType == SampleType::Tumor ? flags |= uint8_t(0b00000010) : flags &= uint8_t(0b11111101);
				judgedType == JudgedType::Mutation ? flags |= uint8_t(0b00000100) : flags &= uint8_t(0b11111011);
				direct == ReadDirection::Reverse ? flags |= uint8_t(0b00001000) : flags &= uint8_t(0b11110111);
			}
			inline SampleType getSampleType() const { return (flags & uint8_t(0b10)) ? SampleType::Tumor : SampleType::Normal; }
			inline JudgedType getJudgedType() const { return (flags & uint8_t(0b100)) ? JudgedType::Mutation : JudgedType::NotMutation; }
			inline ReadDirection getReadDirection() const { return (flags & uint8_t(0b1000)) ? ReadDirection::Reverse : ReadDirection::Forward; }
			inline void reverseReadDirection() { flags ^= uint8_t(0b00001000); }
			inline bool operator<(const ReadInfo& right) const { return readID == right.readID ? ( flags == right.flags ? mutIndex < right.mutIndex : flags < right.flags) : readID < right.readID; }
		};
		struct RawMutationInfo {
			uint64_t commonBases;
			//float normalMatchRate; // = predicted normal reads in normal sample / normal sample reads
			//float mutatedMatchRate; // = predicted mutated reads in tumor sample / tumor sample reads
			uint16_t sourceDivNum;
			uint8_t bpBase;
			std::vector<ReadInfo> predictedNormalReads;
			std::vector<ReadInfo> predictedMutatedReads;
			// bases=>Ascending group=>Ascending count=>Descending
			inline bool operator<(const RawMutationInfo& right) const {
				if (commonBases == right.commonBases) {
					if (sourceDivNum == right.sourceDivNum) {
						if (predictedNormalReads.size() == right.predictedNormalReads.size()) return predictedMutatedReads.size() > right.predictedMutatedReads.size();
						else return predictedNormalReads.size() > right.predictedNormalReads.size();
					}
					else return sourceDivNum < right.sourceDivNum;
				}
				else return commonBases < right.commonBases;
			}
		};

		struct AvgRead {
			std::string readStr;
			uint16_t mutIndex;
			int16_t combineOffset;
		};
		struct AvgReadMeta
		{
			uint32_t rawListIndex1;
			uint32_t rawListIndex2;
		};
		struct AvgReadVector
		{
			std::vector<AvgRead> normal;
			std::vector<AvgRead> mutated;
			std::vector<AvgReadMeta> metas;
			std::vector<float> scores;
			inline size_t size() const {
				return normal.size();
			}
			inline void reserve(size_t size) {
				normal.reserve(size);
				mutated.reserve(size);
				metas.reserve(size);
				scores.reserve(size);
			}
			inline void clear() {
				normal.clear();
				mutated.clear();
				metas.clear();
				scores.clear();
			}
			inline void push_back(AvgRead n, AvgRead m, AvgReadMeta mt, float sc) {
				normal.push_back(n);
				mutated.push_back(m);
				metas.push_back(mt);
				scores.push_back(sc);
			}
		};
		enum BreakpointType {
			SNV, // Single Nucleotide Variant (eg A -> T)
			INS, // Insertion (eg - -> AA)
			DEL, // Deletion (eg AA -> -)
			INV, // Inversion (eg AG -> GA)
			mSNV, // multi-SNV (eg AG -> TT)
			Complex, // Complex of SNV, INS and DEL (eg AG -> CGT [SNV(A->C) + INS(T)])
			Others, // Could not detect types (eg ACGG$ -> TTTTTT$)
		};
		struct BreakpointInfo {
			BreakpointType bpType;
			std::string before;
			std::string after;
			uint16_t offset = 0; // offset from mutIndex
			uint32_t exKey = UINT32_MAX; // index in extra
			bool needsElongation = false;
		};
		struct BreakpointList
		{
			std::vector<BreakpointInfo> main;
			std::multimap<uint32_t, BreakpointInfo> extra;
			inline void clear() {
				main.clear();
				extra.clear();
			}
		};

		void init(read::ReadCollection* readCollecion, uint8_t skipDepth, int sourceDivCount, bool bpMode);

		void append(std::vector<ReadInfo> normalReads, std::vector<ReadInfo> mutationReads, uint16_t sourceDivNum);

		// call this after all append() finished
		void optimize(bool isStrandSpecific);

		std::string overviewResult() const;
		std::string toFasta() const;
		std::string toFastq() const;
		inline size_t foundCount() const { return bpFoundCount_; }
		static void detectBreakpointType(const AvgRead& nAvg, const AvgRead& mAvg, BreakpointList& bps, uint32_t id);
	private:
		// copy constructor is prohibited
		MutationList(const MutationList&) = delete;

		inline std::string bpType2Str(BreakpointType bp) const {
			switch (bp)
			{
			case result::MutationList::SNV:
				return "SNV";
			case result::MutationList::mSNV:
				return "SNV(mSNV)";
			case result::MutationList::INS:
				return "SV(INS)";
			case result::MutationList::DEL:
				return "SV(DEL)";
			case result::MutationList::INV:
				return "SV(INV)";
			case result::MutationList::Complex:
				return "SV(Complex)";
			default:
				return isBPasOthers_ ? "BP(Others)" : "SV(Others)";
			}
		}
		inline std::string bpType2StrSV(BreakpointType bp) const {
			switch (bp)
			{
			case result::MutationList::SNV:
			case result::MutationList::mSNV:
				return "SNV";
			case result::MutationList::INS:
			case result::MutationList::DEL:
			case result::MutationList::INV:
			case result::MutationList::Complex:
				return "SV";
			default:
				return isBPasOthers_ ? "BP" : "SV";
			}
		}

		// list of result
		// contains all information to point out a mutated base
		std::vector<RawMutationInfo> list_;
		AvgReadVector avgList_;
		BreakpointList breakpoints_;
		std::set<uint32_t> skipList_;
		int bpFoundCount_ = 0;
		int bpFoundCountDetail_[3] = { 0, 0, 0 }; // SNV,SV,BP

		// omit duplicate results from the list
		// view the bases of [mutationIndex-refBaseCount+1, mutationIndex] of NormalRead
		// if more than one reads have the same value, then save one of them and delete others.
		// 0 < refBaseCount <= min(skipDepth, 32)
		// larger value means higher specificity and lower sensitivity.
		void combineDuplicates();
		void combineBothDirections(const std::set<uint32_t>& omitList);
		static uint8_t levenshteinDistance(const std::string& read1, int targetIndex1, const std::string& read2, int targetIndex2);
		inline static uint8_t ldAvg(const AvgRead& nAvg, const AvgRead& mAvg, uint8_t skipDepth) {
			return levenshteinDistance(nAvg.readStr.substr(0, nAvg.mutIndex - skipDepth), nAvg.mutIndex - skipDepth - 1, mAvg.readStr.substr(0, mAvg.mutIndex - skipDepth), mAvg.mutIndex - skipDepth - 1);
		}
		std::string reverseReadString(std::string read) const;
		void detectBreakpointTypes();
		std::set<uint32_t> omitLowQualityReads(const BreakpointList& bps);

		void createAllAvgReads();
		float createAvgRead(std::vector<ReadInfo> group, MutationList::AvgRead& avg) const;
		float selectAvgBase(std::vector<std::string>::iterator begin, std::vector<std::string>::iterator end, uint16_t targetIndex, uint16_t endIndex, bool longer, std::string& resStr) const;
		std::string u64toString(uint64_t bases, int length) const;

		std::mutex mtx_;
		read::ReadCollection* reads_;
		int sourceDivCount_;
		const float MinSourceDivHitRate = 0.8f;
		uint8_t skipDepth_;
		bool isBPasOthers_;
	};



	class ClusterIntegration {
	public:
		std::set<uint32_t> static run(result::MutationList::AvgReadVector& avgs, result::MutationList::BreakpointList& bps, const std::set<uint32_t>& omitList);
		float static entropy3(const std::string& read);
	private:
		ClusterIntegration() = delete;
		ClusterIntegration(const ClusterIntegration&) = delete;

		uint32_t static str2ui32(std::string b15);
		uint32_t static reverseUi32(uint32_t bases);

		// n-gram for SNV
		struct ngSNV {
			uint32_t bases;
			uint8_t baseCount; // max 15
			uint32_t id;
			inline bool operator< (const ngSNV& right) const { return bases < right.bases; }
		};
		void static createSNVngs(const std::vector<result::MutationList::AvgRead>& avgs, std::vector<ngSNV>& fwdList, std::vector<ngSNV>& sortedRevList);

		struct trimmedAvgInfo {
			std::string avgRead;
			uint32_t id;
			uint16_t trimStartIndex;
		};
		std::vector<trimmedAvgInfo> static createTrimmedAvgs(const std::vector<result::MutationList::AvgRead>& avgs, const result::MutationList::BreakpointList& bps, const std::set<uint32_t>& omitList);

		// n-gram metainfo for SV
		struct idIdx {
			uint32_t id;
			uint16_t index;
		};
		static constexpr int svNgramLen = 15;
		static constexpr uint32_t svNgramMask = 0xFFFFFFFF >> ((16 - svNgramLen) * 2);
		std::multimap<uint32_t, idIdx> static createSVngs(const std::vector<trimmedAvgInfo>& avgis);

		std::string static reverseReadString(const std::string& read);
		float static calcOverlap(const std::string& read1, int targetIndex1, const std::string& read2, int targetIndex2);
		inline bool static checkOverlap(const std::string& read1, int targetIndex1, const std::string& read2, int targetIndex2) {
			return calcOverlap(read1, targetIndex1, read2, targetIndex2) >= 0.92f;
		}

		struct indexPair {
			uint16_t srcIndex;
			uint16_t destIndex;
		};
		uint32_t static searchSNVPair(const std::vector<ngSNV>& sortedRevNgList, const std::vector<result::MutationList::AvgRead>& avgs, const ngSNV fwdTarget, const std::set<uint32_t>& dupList, indexPair& res);
		uint32_t static searchSVPair(const std::multimap<uint32_t, idIdx>& svmap, const std::vector<result::MutationList::AvgRead>& avgs, const trimmedAvgInfo avgi, const std::set<uint32_t>& dupList, indexPair& res);
	
		uint16_t static uniteTwoAvgs(const result::MutationList::AvgRead& avg1, const result::MutationList::AvgRead& avg2, indexPair idxs, result::MutationList::AvgRead& newAvg);
		uint16_t static updateAvgList(std::vector<result::MutationList::AvgRead>& avgs, uint32_t id1, uint32_t id2, indexPair idxs);
		int static updateLongestMatch(const std::string& readFwd, const std::string& readRev, indexPair& idxs);
		int static searchLongestMatch(const std::string& readFwd, const std::string& readRev, indexPair& idxs);
		int static findLongestMatch(const std::string& read1, const std::string& read2, int& offset);
	};
#pragma pack()
}