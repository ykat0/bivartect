#pragma once
#include <cstdlib>
#include <vector>
#include <map>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <typeinfo>
#include <algorithm>

namespace option {

	enum class ParseResult {
		Succeeded, InvalidFormat, LessOptions, NoOptions, ShowingHelp
	};
	enum class OptionIsBool { No, Yes };
	enum class OptionNecessary { No, Yes };

	class OptionParser {
	public:
		OptionParser() {
			registeredChars_.push_back('h');
			registeredChars_.push_back('H');
			isGeneralField_ = true;
		}

		// 'h' and 'H' is used as HELP
		void add(char alphabet, const std::string& description, OptionIsBool isBool = OptionIsBool::No, OptionNecessary isNecessary = OptionNecessary::No) {
			detailMap_[alphabet] = OptionInfo{ isBool == OptionIsBool::Yes, description, isGeneralField_ };
			if (isNecessary == OptionNecessary::Yes) necessaryChars_.push_back(alphabet);
			registeredChars_.push_back(alphabet);
		}

		void add(char alphabet, const std::string& description, OptionNecessary isNecessary) {
			add(alphabet, description, OptionIsBool::No, isNecessary);
		}

		void switchToGeneralOptionField() { isGeneralField_ = true; }
		void switchToAdvancedOptionField() { isGeneralField_ = false; }

		void setAlias(char alphabet, const std::string& combinedOptions) {
			alias_[alphabet] = combinedOptions;
			registeredChars_.push_back(alphabet);
		}

		ParseResult parse(int argc, char* argv[]) {
			if (argc <= 1) {
				showDefaultMessage(true);
				return ParseResult::NoOptions;
			}
			else {
				showDefaultMessage();
				for (int i = 1; i < argc; i++) {
					if (argv[i][0] == '-') {
						// key
						if (argv[i][1] == 0) {
							// sizeof(argv[i]) == 1
							std::cout << "[Error] Invalid usage of '-'.\n";
							return ParseResult::InvalidFormat;
						}
						if (argv[i][2] != 0) {
							// sizeof(argv[i]) > 2
							std::cout << "[Error] Invalid usage of '-'. One '-' can represent only one alphabet.\n";
							return ParseResult::InvalidFormat;
						}
						if (std::find(registeredChars_.begin(), registeredChars_.end(), argv[i][1]) == registeredChars_.end()) {
							// if the character is not registered
							std::cout << "[Error] Invalid character : \"-" << argv[i][1] << "\".\n";
							return ParseResult::InvalidFormat;
						}
						else {
							// OK
							if (argv[i][1] == 'h') {
								// general help
								showHelp();
								return ParseResult::ShowingHelp;
							}
							else if (argv[i][1] == 'H') {
								// advanced full help
								showHelp(true);
								return ParseResult::ShowingHelp;
							}
							else {
								if (alias_.count(argv[i][1]) != 0) {
									// alias option
									rawArgsFormat_ = alias_[argv[i][1]];
								}
								else {
									// normal option
									if (detailMap_[argv[i][1]].isBool) {
										// OK
										// the option is bool type
										parsedPairs_[argv[i][1]] = "";
									}
									else {
										// the option requires value
										if (i + 1 >= argc) {
											// not contains value
											std::cout << "[Error] \"-" << argv[i][1] << "\" option requires a value.\n";
											return ParseResult::InvalidFormat;
										}
										else {
											// OK
											parsedPairs_[argv[i][1]] = std::string(argv[i + 1]);
											i++;
										}
									}
								}
							}
						}
					}
					else {
						// raw arg
						rawArgs_.push_back(std::string(argv[i]));
					}
				}

				// check alias value count if alias is used
				if (rawArgsFormat_.size() > 0 && rawArgs_.size() != rawArgsFormat_.size()) {
					std::cout << "[Error] selected alias requires " << rawArgsFormat_.size() << " values, but inputs are " << rawArgs_.size() << ".\n";
					return ParseResult::InvalidFormat;
				}
				// check raw args if alias is not used
				if (rawArgsFormat_.size() == 0 && rawArgs_.size() > 0) {
					std::cout << "[Error] though alias is not used, " << rawArgs_.size() << " free arguments are detected.\n";
					return ParseResult::InvalidFormat;
				}
				// replace alias with standard options
				for (int n = 0; n < (int)rawArgs_.size(); n++) {
					parsedPairs_[rawArgsFormat_[n]] = rawArgs_[n];
				}
				// check all necessary options' existence
				for (int n = 0; n < (int)necessaryChars_.size(); n++) {
					if (parsedPairs_.count(necessaryChars_[n]) == 0) {
						std::cout << "[Error] \"-" << necessaryChars_[n] << "\" is necessary, but not exist.\n";
						return ParseResult::LessOptions;
					}
				}

				return ParseResult::Succeeded;
			}
		}

		template <typename T> T get(char alphabet, T defaultValue) {
			if (parsedPairs_.count(alphabet) == 1) {
				T out;
				std::stringstream ss(parsedPairs_[alphabet]);
				ss >> out;
				if (ss.fail()) {
					std::cout << "[Error] type is incorrect. \"-" << alphabet << "\" requires " << typeid(out).name() << ". Use default value instead.\n";
					return defaultValue;
				}
				return out;
			}
			else {
				return defaultValue;
			}
		}

		template <typename T> T getc(char alphabet, T defaultValue, T minValue, T maxValue) {
			T num = get<T>(alphabet, defaultValue);
			if (num < minValue || num > maxValue) {
				T newNum = std::max<T>(std::min<T>(num, maxValue), minValue);
				std::cout << "-" << alphabet << " option\'s value must be between " << minValue << " and " << maxValue << ". ";
				std::cout << "Use " << newNum << " alternatively instead of " << num << ".\n";
				return newNum;
			}
			else {
				return num;
			}
		}


		void setName(const std::string& name) { name_ = name; }
		void setVersion(const std::string& ver) { version_ = ver; }
		void setExamples(const std::string& eg) { examples_ = eg; }
		std::string getNameVer() { return name_ + " v." + version_; }



	private:
		void showDefaultMessage(bool showHelpUsage = false) {
			std::ios::fmtflags flags = std::cout.flags();
			std::cout << name_ + "  v." + version_ + "\n" << std::left;
			if (showHelpUsage) {
				std::cout << " -h: show general help\n -H: show full help\n\n";
			}
			std::cout << std::setiosflags(flags);
		}

		void showHelp(bool showFullHelp = false) {
			auto showOneOption = [](char alphabet, std::string desc) -> void {
				const int ColumnWidth = 8;
				std::cout << std::setw(ColumnWidth) << " -" + std::string{ alphabet };
				std::stringstream ss(desc);
				std::string str;
				bool first = true;
				while (std::getline(ss, str)) {
					if (first) {
						first = false;
						std::cout << str << "\n";
					}
					else {
						std::cout << std::string(ColumnWidth, ' ') << str << "\n";
					}
				}
			};

			std::ios::fmtflags flags = std::cout.flags();
			std::cout << "\nGeneral options:\n";
			for (auto c : registeredChars_) {
				if (detailMap_.count(c) == 0) continue; // skip -h, -H
				OptionInfo info = detailMap_[c];
				if (!info.isGeneralOption) continue;
				showOneOption(c, info.description);
			}
			if (showFullHelp) {
				std::cout << "\nAdvanced options:\n";
				for (auto c : registeredChars_) {
					if (detailMap_.count(c) == 0) continue; // skip -h, -H
					OptionInfo info = detailMap_[c];
					if (info.isGeneralOption) continue;
					showOneOption(c, info.description);
				}
			}
			std::cout << "\nAlias options:\n";
			for (auto itr = alias_.begin(); itr != alias_.end(); itr++) {
				std::string desc = "=";
				for (char c : itr->second) {
					desc += " -" + std::string{ c };
				}
				showOneOption(itr->first, desc);
			}
			std::cout << "\nExamples:\n" << examples_ << "\n" << std::flush;
			std::cout << std::setiosflags(flags);
		}


		struct OptionInfo
		{
			bool isBool;
			std::string description;
			bool isGeneralOption;
		};

		std::map<char, OptionInfo> detailMap_;
		std::map<char, std::string> alias_;
		std::vector<char> registeredChars_;
		std::vector<char> necessaryChars_;
		std::string rawArgsFormat_ = "";
		std::vector<std::string> rawArgs_;
		std::map<char, std::string> parsedPairs_;
		std::string name_, version_;
		std::string examples_;
		bool isGeneralField_;
	};



	template <> std::string OptionParser::get<std::string>(char alphabet, std::string defaultValue) {
		if (parsedPairs_.count(alphabet) == 1) {
			return parsedPairs_[alphabet];
		}
		else {
			return defaultValue;
		}
	}

	template <> bool OptionParser::get<bool>(char alphabet, bool defaultValue) {
		return (parsedPairs_.count(alphabet) == 1) ^ defaultValue;
	}
}