#pragma once

constexpr uint8_t baseA = 0b00;
constexpr uint8_t baseC = 0b01;
constexpr uint8_t baseG = 0b10;
constexpr uint8_t baseT = 0b11;
constexpr uint8_t baseNull = 0b100;

constexpr char baseStrs[5] = { 'A', 'C', 'G', 'T', '-' };

enum Base : uint8_t{
	A = 0,
	C = 1,
	G = 2,
	T = 3,
	Null = 4
};

enum AnalyzeDiv {
	x1 = 0,
	x4 = 2,
	x16 = 4,
	x64 = 6,
	x256 = 8
};

enum SampleType {
	Normal, Tumor
};

enum JudgedType {
	NotMutation, Mutation
};

enum ReadDirection : uint8_t {
	Forward, Reverse
};

template<typename T, int N> inline int elementof(T(&)[N]) { return N; }