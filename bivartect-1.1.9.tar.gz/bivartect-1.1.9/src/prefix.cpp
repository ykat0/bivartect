#include "prefix.hpp"
#include <algorithm>
#include <iostream>
#include <fstream>
#include <ios>
#include <iosfwd>
#include <thread>

using namespace std;

namespace prefix {

	// ################ PrefixUnit ################

	PrefixUnit::PrefixUnit() {
	}

	void PrefixUnit::init(uint32_t readID, uint16_t baseOffset, SampleType sampleType, ReadDirection direct) {
		id_ = readID;
		baseIndex_ = baseOffset;
		baseOffsetL8_ = (uint8_t)(baseOffset & 0xFF);
		flags_ = (uint8_t)(baseOffset >> 8);
		setSampleType(sampleType);
		setReadDirection(direct);
	}


	Base PrefixUnit::getBaseAt(uint8_t localIndex) const {
		// prefix_'s lower 6 bits represents base-count
		if (localIndex >= (prefix_ & 0b00111111)) return Base::Null;
		else return (Base)((prefix_ >> (62 - localIndex * 2)) & 0b11);
	}



	// ################ PrefixCollection ################

	PrefixCollection::PrefixCollection() {
		prefixDictionary_ = nullptr;
	}

	PrefixCollection::~PrefixCollection() {
		deleteDictMemory();
	}

	// 指定範囲のPrefixUnitに対し、次の29塩基分を継ぎ足し読みする。
	void PrefixCollection::loadNext29Bases(read::ReadCollection* reads, PrefixUnit* first, PrefixUnit* last) {
		while (first < last) {
			first->setPrefix(reads->fetchBases29At(first->getSampleType(), first->getID(), first->getBaseIndex(), first->getReadDirection()), 29);
			++first;
		}
	}

	// 解析で使うメモリを確保する。
	bool PrefixCollection::newDictMemory(uint64_t dictSize)
	{
		dictSize_ = dictSize;
		dictIndex_ = 0;

		deleteDictMemory();
		prefixDictionary_ = new(nothrow) PrefixUnit[dictSize];
		if (prefixDictionary_ == nullptr) return false;
		return true;
	}

	// 解析で使ったメモリを解放する。
	void PrefixCollection::deleteDictMemory()
	{
		if (prefixDictionary_ != nullptr) {
			delete[] prefixDictionary_;
			prefixDictionary_ = nullptr;
		}
	}

	// 確保済みのメモリ空間に順にPrefixUnitを格納していく。
	// どういう訳か、確保したメモリより多くのappend()が行われたときはfalseが返される。
	bool PrefixCollection::append(uint64_t prefix, uint8_t prefixBaseCount, uint32_t readID, uint16_t baseOffset, SampleType sampleType, ReadDirection direct) {
		if (dictIndex_ >= dictSize_) return false;
		prefixDictionary_[dictIndex_].init(readID, baseOffset, sampleType, direct);
		prefixDictionary_[dictIndex_].setPrefix(prefix, prefixBaseCount);
		++dictIndex_;
		return true;
	}


	void PrefixCollection::sort(PrefixUnit* first, PrefixUnit* last, uint16_t threadCount) const {
		if (prefixDictionary_ != nullptr) {
			if (threadCount > 1 && last - first >= 100000) {
				uint_fast8_t maxDepth = 0;
				while (threadCount > 1)
				{
					threadCount >>= 1;
					maxDepth++;
				}
				pSort(first, last, 0, maxDepth);
				// divide range
				/*auto div = (last - first) / threadCount;
				vector<PrefixUnit*> region;
				region.reserve(threadCount + 1);
				for (int i = 0; i < threadCount; i++) {
					region.push_back(first + i * div);
				}
				region.push_back(last);

				// sort each range
				vector<thread> ths;
				ths.reserve(threadCount - 1);
				for (int i = 0; i < threadCount - 1; i++) {
					ths.push_back(thread(std::sort<PrefixUnit*>, region[i], region[i + 1]));
				}
				std::sort<PrefixUnit*>(region[threadCount - 1], region[threadCount]);
				for (auto& th : ths) if (th.joinable()) th.join();

				// combine ranges and sort again
				pMerge(region);*/
			}
			else {
				std::sort(first, last);
			}
		}
	}


	PrefixUnit* PrefixCollection::getSameRange(PrefixUnit* start) const {
		uint64_t refPrefix = start->getPrefix();
		while (++start <= dictEndPtr()) {
			if (start->getPrefix() != refPrefix) break;
		}
		return start - 1;
	}


	QuadInfo PrefixCollection::createQuadInfo(PrefixUnit* first, PrefixUnit* last, uint8_t localIndex, uint16_t minHBaseCount, uint16_t minLBaseCount) {
		QuadInfo qinfo;
		qinfo.load(first, last, localIndex, minHBaseCount, minLBaseCount);
		return move(qinfo);
	}

	void PrefixCollection::pSort(PrefixUnit * first, PrefixUnit * last, uint_fast8_t depth, uint_fast8_t maxDepth) const
	{
		auto size = last - first;
		if (depth == maxDepth || size < 1000000) {
			std::sort(first, last);
		}
		else {
			constexpr int sample = 10;
			std::sort(first, first + sample * 2 + 1);
			PrefixUnit pivot = *(first + sample);
			PrefixUnit* mid = partition(first + 1, last, [pivot](PrefixUnit a) {return a < pivot; }); // [first,mid) [mid, last) pred(mid)==false
			depth++;
			thread th1 = thread(&PrefixCollection::pSort, this, first, mid, depth, maxDepth);
			thread th2 = thread(&PrefixCollection::pSort, this, mid, last, depth, maxDepth);
			if (th1.joinable()) th1.join();
			if (th2.joinable()) th2.join();
		}
	}

	void PrefixCollection::pMerge(const std::vector<PrefixUnit*>& reg) const
	{
		// reg == [start,reg1start,reg2start,,reg$start,end]
		int count = (int)reg.size() - 1;
		if (count <= 1) return;
		if (count == 2) {
			// Non MT inplace_merge
			inplace_merge(reg[0], reg[1], reg[2]);
			return;
		}
		else {
			// MT inplace_merge 
			/*vector<thread> ths(count / 2 - 1);
			for (int i = 1; i <= count / 2 - 1; i++) {
				ths[i - 1] = thread(&inplace_merge<PrefixUnit*>, reg[i * 2], reg[i * 2 + 1], reg[i * 2 + 2]);
			}
			inplace_merge(reg[0], reg[1], reg[2]);
			for (int t = 0; t < (int)ths.size(); t++) ths[t].join();*/
			for (int i = 0; i < count / 2; i++) {
				inplace_merge(reg[i * 2], reg[i * 2 + 1], reg[i * 2 + 2]);
			}
		}
		vector<PrefixUnit*> newReg;
		newReg.reserve(reg.size() / 2 + 1);
		for (int i = 0; i < (int)reg.size() - 1; i += 2) newReg.push_back(reg[i]);
		newReg.push_back(reg[reg.size() - 1]);
		pMerge(newReg);
	}



#ifndef NDEBUG
	void PrefixCollection::_dumpDictionary(bool as29baseMode) {
		_dumpDictionary(dictBeginPtr(), dictEndPtr(), as29baseMode);
	}

	void PrefixCollection::_dumpDictionary(PrefixUnit* start, PrefixUnit* end, bool as29baseMode) {
		if (start == nullptr || end == nullptr) {
			cout << "NULL\n";
		}
		else {
			printf("Count=%d\n", (int)(end - start + 1));
			for (; start <= end; start++) {
				printf("0x%016llx %s  %s off:%02d idx:%02d id:%d\n",
					(unsigned long long)start->getPrefix(),
					read::ReadCollection::_ui64toString(start->getPrefix(), as29baseMode).data(),
					(start->getSampleType() == SampleType::Tumor ? "Tmr" : "Nrm"),
					start->getBaseOffset(),
					start->getBaseIndex(),
					start->getID());
			}
		}
	}
#endif



	// ################ QuadInfo ################

	QuadInfo::QuadInfo() {

	}

	void QuadInfo::load(PrefixUnit* first, PrefixUnit* last, uint8_t localIndex, uint16_t minHBaseCount, uint16_t minLBaseCount) {
		startPtr_ = first;
		minLBaseCount_ = minLBaseCount;
		minHBaseCount_ = minHBaseCount;
		for (int i = 0; i < elementof(counts_); i++) counts_[i] = 0;
		accumCounts_[0] = 0;
		uint32_t forwardCounts[4] = { 0,0,0,0 };

		// counts up A,C,G,T,N
		while (first < last) {
			switch (first->getBaseAt(localIndex)) {
			case Base::Null:
				accumCounts_[0]++;
				break;
			case Base::A:
				counts_[0]++;
				if (first->getSampleType() == SampleType::Tumor) counts_[1]++;
				if (first->getReadDirection() == ReadDirection::Forward) forwardCounts[0]++;
				break;
			case Base::C:
				counts_[2]++;
				if (first->getSampleType() == SampleType::Tumor) counts_[3]++;
				if (first->getReadDirection() == ReadDirection::Forward) forwardCounts[1]++;
				break;
			case Base::G:
				counts_[4]++;
				if (first->getSampleType() == SampleType::Tumor) counts_[5]++;
				if (first->getReadDirection() == ReadDirection::Forward) forwardCounts[2]++;
				break;
			case Base::T:
				counts_[6]++;
				if (first->getSampleType() == SampleType::Tumor) counts_[7]++;
				if (first->getReadDirection() == ReadDirection::Forward) forwardCounts[3]++;
				break;
			}
			++first;
		}
		accumCounts_[1] = counts_[0] + accumCounts_[0];
		accumCounts_[2] = counts_[2] + accumCounts_[1];
		accumCounts_[3] = counts_[4] + accumCounts_[2];
		accumCounts_[4] = counts_[6] + accumCounts_[3];
		if (counts_[0] > 0 && forwardCounts[0] > 0 && forwardCounts[0] < counts_[0]) containsBothDirections_[0] = true;
		else containsBothDirections_[0] = false;
		if (counts_[2] > 0 && forwardCounts[1] > 0 && forwardCounts[1] < counts_[2]) containsBothDirections_[1] = true;
		else containsBothDirections_[1] = false;
		if (counts_[4] > 0 && forwardCounts[2] > 0 && forwardCounts[2] < counts_[4]) containsBothDirections_[2] = true;
		else containsBothDirections_[2] = false;
		if (counts_[6] > 0 && forwardCounts[3] > 0 && forwardCounts[3] < counts_[6]) containsBothDirections_[3] = true;
		else containsBothDirections_[3] = false;
	}


	bool QuadInfo::getRange(Base base, PrefixUnit*& start, uint32_t& length) {
		switch (base) {
		case Null:
			start = startPtr_;
			length = accumCounts_[0];
			return length > minHBaseCount_;
		case A:
			start = startPtr_ + accumCounts_[0];
			length = counts_[0];
			return length > minHBaseCount_;
		case C:
			start = startPtr_ + accumCounts_[1];
			length = counts_[2];
			return length > minHBaseCount_;
		case G:
			start = startPtr_ + accumCounts_[2];
			length = counts_[4];
			return length > minHBaseCount_;
		case T:
			start = startPtr_ + accumCounts_[3];
			length = counts_[6];
			return length > minHBaseCount_;
		default:
			// not reach
			return false;
		}
	}


	QuadInfo::AnalyzeResult QuadInfo::analyze(uint16_t globalIndex, result::MutationList* mutList, float minMutationMatchRate, float maxMutationMatchRate, float minNormalMatchRate, bool needBothDirection, uint16_t sourceDivNum)
	{
		// in most cases, this method returns Zero or One
		// eliminate them with lightest-weight calc
		// this code fasten the analyze about 10% on my machine
		int hCount = 0, lCount = 0;
		for (int i = 0; i < 4; i++) {
			if (counts_[i * 2] >= minHBaseCount_) hCount++;
			else if (counts_[i * 2] >= minLBaseCount_) lCount++;
		}
		if (hCount == 0) return QuadInfo::AnalyzeResult::Zero;
		if (hCount == 1 && lCount == 0) return QuadInfo::AnalyzeResult::One;

		// if not Zero or One, recalc
		struct QuadStat {
			float mutReadRatio;
			uint32_t count;
			Base base;
			bool isBothDirections;
		};
		QuadStat stat[4];
		int statIndex = 0;
		for (int i = 0; i < 4; i++) {
			if (counts_[i * 2] >= minLBaseCount_) {
				stat[statIndex++] = QuadStat{ (float)counts_[i * 2 + 1] / counts_[i * 2], counts_[i * 2], (Base)i, containsBothDirections_[i] };
			}
		}
		normalBase = Base::Null;
		// sort by ratio then consider largest one to be a mutated reads cluster
		sort(&stat[0], &stat[statIndex], [](const QuadStat& left, const QuadStat& right) {return left.mutReadRatio == right.mutReadRatio ? left.count < right.count : left.mutReadRatio < right.mutReadRatio; });
		QuadStat mutStat = stat[statIndex - 1];
		// remove the mutated read and continue
		statIndex--;
		// sort by count then consider largest one to be a normal reads cluster
		sort(&stat[0], &stat[statIndex], [](const QuadStat& left, const QuadStat& right) {return left.count == right.count ? left.mutReadRatio > right.mutReadRatio : left.count < right.count; });
		QuadStat nrmStat = stat[statIndex - 1];
		// if the normal reads cluster contains no read derived from the normal sample, then exit
		if (nrmStat.mutReadRatio == 1) return QuadInfo::AnalyzeResult::Zero;

		int ni = (int)nrmStat.base * 2;
		int mi = (int)mutStat.base * 2;
		uint32_t ninn = counts_[ni] - counts_[ni + 1];
		float nr = (float)ninn / (ninn + (counts_[mi] - counts_[mi + 1]));
		float mr = (float)counts_[mi + 1] / (counts_[mi + 1] + counts_[ni + 1]);
		if (maxMutationMatchRate == 1.0f) maxMutationMatchRate = 2.0f; // 

		if (nr >= minNormalMatchRate && mr >= minMutationMatchRate && mr <= maxMutationMatchRate && (!needBothDirection || mutStat.isBothDirections)) {
			uint32_t normalCount = counts_[ni];
			uint32_t mutationCount = counts_[mi];
			vector<result::MutationList::ReadInfo> normalReads, mutationReads;
			normalReads.reserve(normalCount);
			mutationReads.reserve(mutationCount);
			PrefixUnit* nrmPrefix = startPtr_ + accumCounts_[(int)nrmStat.base];
			PrefixUnit* mutPrefix = startPtr_ + accumCounts_[(int)mutStat.base];
			for (uint32_t i = normalCount; i > 0; i--) {
				result::MutationList::ReadInfo readi;
				readi.readID = nrmPrefix->getID();
				readi.mutIndex = (uint16_t)(nrmPrefix->getBaseOffset() + globalIndex);
				readi.setFlags(nrmPrefix->getSampleType(), JudgedType::NotMutation, nrmPrefix->getReadDirection());
				normalReads.push_back(readi);
				nrmPrefix++;
			}
			for (uint32_t i = mutationCount; i > 0; i--) {
				result::MutationList::ReadInfo readi;
				readi.readID = mutPrefix->getID();
				readi.mutIndex = (uint16_t)(mutPrefix->getBaseOffset() + globalIndex);
				readi.setFlags(mutPrefix->getSampleType(), JudgedType::Mutation, mutPrefix->getReadDirection());
				mutationReads.push_back(readi);
				mutPrefix++;
			}
			mutList->append(normalReads, mutationReads, sourceDivNum);
			return QuadInfo::AnalyzeResult::ListedDiv;
		}
		else {
			return QuadInfo::AnalyzeResult::NotListedDiv;
		}
	}

}