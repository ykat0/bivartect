/*
Support only C++11 or newer
*/
/*
Change Log
18/2/3 -> v1.0.1
 -aオプション追加
 FASTQ出力に対応
 breakpointの(簡易)種類判別に対応
 解析中の標準出力をこまめにflushするように
 解析結果の標準出力を充実
18/2/6 -> v1.0.2
 スペル修正の反映
 INS/DELをSVに統合
 breakpoint種別判定時の読み枠を8から6に変更
 INS/DELの表記方法変更(TAGG:-をCTAGG:Cに)
18/2/7 -> v1.0.3
 breakpointの位置を全ての変異型で固定
 SV(INS/DEL)の表記方法再変更(CTAGG:CをTAGG:-に)
18/2/8 -> v1.0.4
 二段階SNV判定追加(読み枠3)
 -b隠しオプション追加
18/2/13 -> v1.0.5
 二段階SNV判定時の読み枠を4に変更
18/2/18 -> v1.0.6
 -bオプションの作用反転
 fasta/fastq出力時に記載されるリード長を伸長(固定長→可変長になったので要注意)
 -xオプションのデフォルト値の変更(16→64)
18/2/22 -> v1.0.7
 Bug fix (combineBothDirections()で配列外へのアクセスが起こるバグを修正)
18/2/23 -> v1.0.8
 INV判定実装
18/3/1 -> v1.0.9
 コンセンサス配列算出時に特定の条件下で計算結果を誤るバグを修正
 コンセンサス配列算出時の計算量を削減
 リードのレート計算結果を保持せずに、結果ビューのときに再計算するよう変更 (検出率には影響なし)
 MT動作時に結果にブレが生じる現象に対処
 特定のSVをSNVと誤判定してしまう現象に対処
 重複リード統合の際に、なるべく多くのリードを情報源に用いる処理を追加
 重複リード統合の際に、前部に共通塩基列を持つがBPの位置の塩基が異なる場合は、そのリード集合を全て破棄するように処理を追加
 コンセンサス配列を得る際に、分枝を点数付けしながら積算し、結果が既定点数に満たない場合はそのリード集合を全て破棄するように処理を追加
 改変に伴い、result.cppで新たに<set>をinclude
18/3/3 -> v1.0.10
 BP判定アルゴリズムの変更(任意塩基長から任意塩基長への変化を一致塩基長優先で検出できる)
 match数とそれ以降の残り塩基数から結果の信頼度を求めてスクリーニング
 複合SVSNVへの暫定簡易対応
18/3/5 -> v1.0.11
 Bug fix
18/3/8 -> v1.0.12
 デバッグ用に微修正
18/3/19 -> v1.1.0
 逆向きリードを用いたSV検出を実装
 大規模SVにも試験対応(大規模SVの予測不能欠損部分を"*"で代用して出力する仕様にしたため、fastq(mfasta)に*記号が出現しうる)
 1つの変異を両方向で検出した際に、両者を完全に統合できるように対応
 これに伴い、相補鎖クラスターを結果から除去するアルゴリズムを全削除
 いくつかのデータ構造の微修正
18/3/23 -> v1.1.1
 BP判定を伸長よりも先行するように変更
 複合SVSNVの出力に対応できるようにプラットフォームの敷設
18/3/28 -> v1.1.2
 相補鎖でコンセンサス配列を伸長する際に、最長マッチとなるように再計算
 参照距離とコンセンサス配列復元スコアから低クオリティBPを弾く
18/4/7 -> v1.1.3
 mSNV/Complexの解析工程を実装
 大SV伸長の際に、マッチ部分のエントロピーを計算し、値が低いものを誤マッチと判断
18/5/10 -> v1.1.4
 -sオプションのバグを修正
18/5/19 -> v1.1.5
 mSNVにおけるSNV判定処理のバグを修正
18/5/24 -> v1.1.6
 カットオフの仕様変更(-Cオプションの追加)
 -oオプションを必須オプションから格下げ(-rの出力だけ見たい可能性があるため)
 メモリ確保に失敗した場合も正常にプログラムを終了できるように処理を追加
 QuadInfo::analyze()でメモリの動的確保が起こらないように最適化
 -tが奇数のときクラッシュするバグを修正
18/6/3 -> v1.1.7
 thread関連の書き方をより安全なものへ変更(効果不明)
 マルチスレッドSortをまるごと書き換え
 →inplace_merge()によるメモリ動的確保が一切起こらなくなり、メモリ使用量のサージが完全消滅
18/6/10 -> v1.1.8
 -pオプションを-Pに変更
 -qオプションを-pに変更
 マッチレート上限を表す-qオプションを新規追加
 これに伴い、一部をfloatからdoubleに変更
 OptionParserクラスの利便性向上
 実験的にstoringフェイズをマルチスレッドにしてみたがかえって遅くなったので元に戻す
18/7/8 -> v1.1.9
 Help文章の修正
 特定条件下でファイル読み込みが止まるバグを修正
*/

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <algorithm>
#include "read.hpp"
#include "prefix.hpp"
#include "result.hpp"
#include "option.hpp"
#include "analyze.hpp"

using namespace std;
using namespace read;
using namespace prefix;
using namespace result;
using namespace analyze;
using namespace option;


int main(int argc, char* argv[])
{
	OptionParser options;
	options.setName("Bivartect");
	options.setVersion("1.1.9");

	options.switchToGeneralOptionField();
	options.add('n', "Path to the normal FASTQ (string [necessary])", OptionNecessary::Yes);
	options.add('N', "Path to the normal reversed FASTQ (string)");
	options.add('m', "Path to the mutated FASTQ (string [necessary])", OptionNecessary::Yes);
	options.add('M', "Path to the mutated reversed FASTQ (string)");
	options.add('o', "Path to the output FASTQ (string)");
	options.add('a', "Output multi-FASTA instead of FASTQ (bool [false])", OptionIsBool::Yes);
	options.add('s', "Input FASTQ is strand-specific (bool [false])", OptionIsBool::Yes);
	options.add('d', "Filtering depth (int 10...32 [22])");
	options.add('c', "Read count cutoff.\nIn a breakpoint cluster, \nIF max(predictedNormalReadCount, predictedMutatedReadCount) < c \nTHEN omit the breakpoint because of low quality. (int 1...100 [8])");
	options.add('x', "Analysis division rate (int 1,4,16,64...1024 [64])");
	options.add('t', "Using thread count. Set 0 to use hardware maximum threads (int 0... [0])");
	options.add('r', "Path to the output detail overview text file (string)");

	options.switchToAdvancedOptionField();
	options.add('b', "Don\'t use BP in the result file (bool [false])", OptionIsBool::Yes);
	options.add('v', "Show overview result in console (bool [false])", OptionIsBool::Yes);
	options.add('C', "Read count lower cutoff. (Must be at most c value.)\nIn a breakpoint cluster, \nIF min(predictedNormalReadCount, predictedMutatedReadCount) < C \nTHEN omit the breakpoint because of low quality. (int 1...100 [6])");
	options.add('p', "Threshold of lower mutation match rate. \nIn a breakpoint cluster, \nIF (predictedMutatedReadCountInTumorSample / totalReadCountInTumorSample) < p \nTHEN omit the breakpoint because of low quality. (float 0.3...1.0 [0.9])");
	options.add('q', "Threshold of upper mutation match rate. (Must be larger than p value.)\nIn a breakpoint cluster, \nIF (predictedMutatedReadCountInTumorSample / totalReadCountInTumorSample) > q \nTHEN omit the breakpoint because of low quality. (float 0.3...1.0 [1.0])");
	options.add('P', "Threshold of lower normal match rate (float 0.5...1.0 [0.95])");
	//options.add('w', "[NOT WORK NOW] Input source divide count (int 1,2...10 [1])");
	//options.add('z', "Directory where temp files are exported (used only when -w option is >1).\nIf not set, use the fastq directory (string)");

	options.setAlias('2', "nm");
	options.setAlias('3', "nmo");
	options.setAlias('4', "nNmM");
	options.setAlias('5', "nNmMo");

	string examples = "$ bivartect -x 16 -d 30 -c 6 -n <normal.fastq> -m <tumor.fastq> -o <output.fastq>\n";
	examples += "$ bivartect -3 <normal.fastq> <tumor.fastq> <output.fastq> -c 4\n";
	examples += "$ bivartect -5 <normal_1.fastq> <normal_2.fastq> <tumor_1.fastq> <tumor_2.fastq> <output.fastq>\n";
	examples += "$ bivartect -2 <normal.fastq> <tumor.fastq> -r <output.txt>\n";
	options.setExamples(examples);

	if (options.parse(argc, argv) != ParseResult::Succeeded) {
		return 0;
	}

	vector<string> nrmFwdPaths, tmrFwdPaths, nrmRevPaths, tmrRevPaths;
	nrmFwdPaths.push_back(options.get<string>('n', ""));
	nrmRevPaths.push_back(options.get<string>('N', ""));
	tmrFwdPaths.push_back(options.get<string>('m', ""));
	tmrRevPaths.push_back(options.get<string>('M', ""));
	bool isStrandSpecific = options.get<bool>('s', false);
	bool showResInConsole = options.get<bool>('v', false);
	bool isFasta = options.get<bool>('a', false);
	bool bpMode = !options.get<bool>('b', false);
	uint16_t threadCount = (uint16_t)options.getc<int>('t', 0, 0, 0xFFFF);
	string resFastqaPath = options.get<string>('o', "");
	string detailPath = options.get<string>('r', "");
	string tempDir = options.get<string>('z', "");
	uint8_t skipDepth = (uint8_t)options.getc<int>('d', 22, 10, 32);
	uint16_t minHBaseCount = (uint16_t)options.getc<int>('c', 8, 1, 100);
	uint16_t minLBaseCount = (uint16_t)options.getc<int>('C', 6, 1, 100);
	if (minLBaseCount > minHBaseCount) minLBaseCount = minHBaseCount;
	float minMutRate = options.getc<float>('p', 0.9f, 0, 1);
	float maxMutRate = options.getc<float>('q', 1.0f, 0, 1);
	if (maxMutRate < minMutRate) maxMutRate = minMutRate;
	float minNrmRate = options.getc<float>('P', 0.95f, 0, 1);
	int sourceDiv = options.getc<int>('w', 1, 1, 10);
	int div = options.getc<int>('x', 64, 1, 1024);
	int divPow = 0;
	while (div > 1) {
		div >>= 2;
		divPow += 2;
	}
	AnalyzeDiv prefixDivRate = (AnalyzeDiv)divPow;
	div = 1 << divPow;

	if (nrmFwdPaths[0].size() == 0 || tmrFwdPaths[0].size() == 0) return 0;
	if ((nrmRevPaths[0].size() == 0) ^ (tmrRevPaths[0].size() == 0)) return 0;

	chrono::time_point<chrono::system_clock> startTime = chrono::system_clock::now();
	ReadCollection reads(skipDepth, prefixDivRate, sourceDiv); //---
	cout << "Loading files..." << flush;
	bool isReadMallocSucceeded = reads.loadFiles(nrmFwdPaths, nrmRevPaths, tmrFwdPaths, tmrRevPaths, isStrandSpecific, tempDir);
	if (!isReadMallocSucceeded) {
		cout << "Memory Allocation Failed!!!\nInput file is too large!";
		return 0;
	}
	cout << "finished\n";
	chrono::time_point<chrono::system_clock> endTime1 = chrono::system_clock::now();
	//auto endTime2 = chrono::system_clock::now();
	PrefixCollection prefixs;
	Analyze analyzer;
	MutationList mutList;
	analyzer.init(skipDepth, (uint16_t)max(minHBaseCount / sourceDiv, 2), (uint16_t)max(minLBaseCount / sourceDiv, 2), minMutRate, maxMutRate, minNrmRate, !isStrandSpecific, threadCount);
	mutList.init(&reads, skipDepth, sourceDiv, bpMode);
	int normalSrcDivNum = 1, tumorSrcDivNum = 1;
	while (normalSrcDivNum <= sourceDiv && tumorSrcDivNum <= sourceDiv) {
		uint16_t stage = (uint16_t)((normalSrcDivNum - 1) * sourceDiv + tumorSrcDivNum);
		if (sourceDiv > 1) {
			cout << "STAGE:" << stage << "/" << sourceDiv * sourceDiv << "\n";
			reads.loadTempFiles(SampleType::Normal, normalSrcDivNum);
			reads.loadTempFiles(SampleType::Tumor, tumorSrcDivNum);
		}
		reads.countPrefixPatterns();
		for (uint16_t i = 0; i < div; i++) {
			cout << "Region: " << i + 1 << "/" << div << "  storing..." << flush;
			bool isPrefixMallocSucceeded = reads.storePrefixUnits(&prefixs, i, skipDepth);
			if (!isPrefixMallocSucceeded) {
				cout << "Memory Allocation Failed!!!\nPlease use larger -x value!";
				return 0;
			}
			cout << "analyzing..." << flush;
			analyzer.run(&reads, &prefixs, &mutList, stage);
			cout << "finished\n" << flush;
		}
		prefixs.deleteDictMemory();
		if (tumorSrcDivNum == sourceDiv) {
			tumorSrcDivNum = 1;
			normalSrcDivNum++;
		}
		else {
			tumorSrcDivNum++;
		}
	}
	chrono::time_point<chrono::system_clock> endTime3 = chrono::system_clock::now();
	mutList.optimize(isStrandSpecific);

	chrono::time_point<chrono::system_clock> endTime10 = chrono::system_clock::now();
	if (resFastqaPath != "") {
		ofstream ofs(resFastqaPath, ios::binary);
		if (isFasta) ofs << mutList.toFasta();
		else ofs << mutList.toFastq();
	}
	char buf[100];
	auto getSec = [](chrono::time_point<chrono::system_clock> begin, chrono::time_point<chrono::system_clock> end) { return chrono::duration_cast<chrono::milliseconds>(end - begin).count() / 1000.F; };
	snprintf(buf, sizeof(buf), "Time: %.3f sec\n---------Detail---------\n", getSec(startTime, endTime10));
	string temp = buf;
	string output2 = temp;
	snprintf(buf, sizeof(buf), "Input --> Load FASTQ files      %.3f sec\n", getSec(startTime, endTime1));
	temp = buf;
	output2 += temp;
	snprintf(buf, sizeof(buf), " --> Analyze and store result   %.3f sec\n", getSec(endTime1, endTime3));
	temp = buf;
	output2 += temp;
	snprintf(buf, sizeof(buf), " --> Analyze result --> Output  %.3f sec\n\n", getSec(endTime3, endTime10));
	temp = buf;
	output2 += temp;

	cout << "\n";
	if (showResInConsole) cout << mutList.overviewResult();
	else cout << mutList.foundCount() << " mutation(s) detected.\n";
	cout << output2 << flush;

	if (detailPath != "") {
		ofstream ofs(detailPath, ios::binary);
		ofs << options.getNameVer() << "\n";
		ofs << "-c " << minHBaseCount << " -d " << (int)skipDepth << "\n\n";
		ofs << mutList.overviewResult();
		ofs << output2;
	}
	//system("pause"); ///////////////////
	return 0;
}
