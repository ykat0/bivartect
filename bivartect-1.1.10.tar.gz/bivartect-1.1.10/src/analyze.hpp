#pragma once
#include <cstdlib>
#include <vector>
#include <string>
#include "base.hpp"
#include "read.hpp"
#include "prefix.hpp"
#include "result.hpp"

//namespace prefix { class PrefixUnit; }

namespace analyze {
#pragma pack(8)
	class Analyze {
	public:
		Analyze();

		void init(uint16_t skipDepth, uint16_t minHBaseCount, uint16_t minLBaseCount, float minMutationMatchRate, float maxMutationMatchRate, float minNormalMatchRate, bool isSingleEnd, uint16_t threadCount);
		void run(read::ReadCollection* reads, prefix::PrefixCollection* prefixs, result::MutationList* mutList, uint16_t sourceDivNum);

	private:
		read::ReadCollection* reads_;
		prefix::PrefixCollection* prefixs_;
		result::MutationList* mutList_;
		float minNormalMatchRate_, minMutationMatchRate_, maxMutationMatchRate_;
		uint16_t minHBaseCount_, minLBaseCount_;
		uint16_t skipDepth_;
		uint16_t sourceDivNum_;
		uint16_t threadCount_;
		bool needBothDirection_;

		void formar(prefix::PrefixUnit* first, prefix::PrefixUnit* last, uint16_t remainSkipDepth);
		void mtTask(prefix::PrefixUnit* first, prefix::PrefixUnit* last);
		void latter(prefix::PrefixUnit* first, prefix::PrefixUnit* last, uint8_t localIndex, uint16_t globalIndex);
	};
#pragma pack()
}