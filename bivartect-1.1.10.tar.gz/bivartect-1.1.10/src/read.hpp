#pragma once
#include <cstdlib>
#include <vector>
#include <string>
#include "base.hpp"
#include "prefix.hpp"

namespace prefix { class PrefixCollection; }

namespace read {
	constexpr int BlockReadShiftCount = 6;
	constexpr uint16_t BlockReadCount = 1 << BlockReadShiftCount;

#pragma pack(8)
	class FastqReader {
	public:

		FastqReader(uint8_t skipDepth);

		// set fastq file paths. if not paired-end reads, set empty vector to normalRevPaths or tumorRevPaths.
		// if tempPath is empty, use normalFwdPaths[0]`s directory as tempPath.
		void setFiles(std::vector<std::string> normalFwdPaths, std::vector<std::string> normalRevPaths, std::vector<std::string> tumorFwdPaths, std::vector<std::string> tumorRevPaths);
		
		// set readNext() and getReverseStartAt() `s target
		void setTarget(SampleType sampleType);
		
		enum AccessResult {
			Success, Finished, OpenFailed, BufferDeficiency
		};
		// each time you call getReadBlockNext(), returns new readBlock
		AccessResult getNextReadBlock(char* buff, int buffSize, int& buffUsedBytes, int& itemCount);
		
		// returns the id where reverse read starts.
		// if readID < thisValue, the read is forward read, otherwise reverse read.
		inline uint32_t getReverseStartAt() { return revStartID_; }

	private:

		bool trimBases(std::string& baseStr, ReadDirection direct);


		uint8_t skipDepth_;
		std::vector<std::string> normalFwdPaths_ ,normalRevPaths_;
		std::vector<std::string> tumorFwdPaths_, tumorRevPaths_;
		bool targetChanged_;
		SampleType sampleType_;
		uint32_t revStartID_;
	};
#pragma pack()



#pragma pack(8)
	class ReadCollection {
	public:
		ReadCollection(uint8_t skipDepth, AnalyzeDiv div, int sourceDivCount);
		~ReadCollection();

		// Load fastq files and store the data
		bool loadFiles(std::vector<std::string> normalFwdPaths, std::vector<std::string> normalRevPaths, std::vector<std::string> tumorFwdPaths, std::vector<std::string> tumorRevPaths, bool isStrandSpecific, std::string tempDir);
		// Num=1~
		bool loadTempFiles(SampleType sampleType, int sourceDivNum);
		void deleteReadOnMemory(SampleType sampleType);
		void countPrefixPatterns();

		// prefixPrefixは下揃え
		// 指定接頭辞の相補鎖及び、探査方向両方向の全4パターンを自動で行う
		// prefixPrefixは想定される全てを渡せばOK。既に探査したかどうかは内部でチェックできる
		bool storePrefixUnits(prefix::PrefixCollection* prefixCol, uint16_t prefixPrefix, uint8_t length);
		uint64_t fetchBases32At(SampleType sampleType, uint32_t id, uint16_t index, uint8_t length, ReadDirection direct) const;
		uint64_t fetchBases29At(SampleType sampleType, uint32_t id, uint16_t index, ReadDirection direct) const;
		std::string fetchReadString(SampleType sampleType, uint32_t id, bool usingTempFile, ReadDirection direct) const;
		uint16_t getBaseCount(SampleType sampleType, uint32_t id) const;

		//inline ReadDirection getDirection(SampleType sampleType, uint32_t id) { return (id >= (sampleType == SampleType::Tumor ? tumorRevID_ : normalRevID_)) ? ReadDirection::Reverse : ReadDirection::Forward; }
		inline size_t consumingMemory() const { return 0; }

	private:
		// copy constructor is prohibited
		ReadCollection(const ReadCollection&) = delete;

		// address where a read block is placed on the memory
		// use this vector as hash sheet
		std::vector<uint8_t*> normalReadBlocks_;
		std::vector<uint8_t*> tumorReadBlocks_;
		// file pointer where a read block is placed on the temporary file
		std::vector<uint64_t> normalBlockFilePtrs_;
		std::vector<uint64_t> tumorBlockFilePtrs_;
		// estimated prefix unit count per a prefix's prefix
		// 高速化のためrev側は逆相補鎖変換する"前"の塩基列をIndexとしているので注意
		// つまりACCCから始まる塩基列の数を知りたければ、fwd[ACCC]とrev[GGGT]を合算すればいい
		std::vector<uint64_t> prefixFwdCounts_, prefixRevCounts_;
		// count of all reads
		uint32_t normalReadCount_;
		uint32_t tumorReadCount_;

		std::vector<uint8_t> reverseBasesMap_;

		uint8_t skipDepth_;
		AnalyzeDiv analyzeDiv_;
		std::string normalTempPath_, tumorTempPath_;
		uint32_t normalBlockOffset_, tumorBlockOffset_;
		uint32_t normalRevID_, tumorRevID_;
		int sourceDivCount_;
		bool isStrandSpecific_;


		bool loadFiles(SampleType sampleType, FastqReader* fastqReader, std::string tempDir);
		inline uint8_t* fetchBlockPtr(SampleType sampleType, uint32_t id) const;
		inline uint8_t* fetchReadPtr(SampleType sampleType, uint32_t id, uint16_t& baseCount) const;
		uint64_t fetchBases32AtPtr(uint8_t* readPtr, uint16_t baseCount, uint16_t index, uint8_t length) const;
		uint64_t fetchReverseBases32AtPtr(uint8_t* readPtr, uint16_t baseCount, uint16_t index, uint8_t length) const;
		bool fileToMemory(std::string tmpPath, std::vector<uint64_t>* blockFilePtrs, size_t startIndex, size_t endIndex, std::vector<uint8_t*>* readBlocks);
		// convert "AACG" to "CGTT"
		inline uint8_t reverse4Bases(uint8_t target) const { return reverseBasesMap_[target]; }
		inline uint16_t reverse8Bases(uint16_t target) const { return (reverseBasesMap_[target & 0xFF] << 8) + reverseBasesMap_[(target >> 8)]; }


#ifndef NDEBUG
	public:
		void _dump();
		static std::string _ui64toString(uint64_t val, bool as29baseMode);
	private:
		void _dumpBlocks(std::vector<uint8_t*> readBlocks, uint32_t blockOffset);
		void _dumpFilePtrs(std::vector<uint64_t> blockFilePtrs);
		void _dumpPrefixCounts();
#endif
	};
#pragma pack()
}