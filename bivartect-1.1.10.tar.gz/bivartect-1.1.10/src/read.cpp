#include "read.hpp"
#include <iostream>
#include <fstream>
#include <ios>
#include <iosfwd>
#include <algorithm>
#include <sys/stat.h> // for checking dir existence
#include <new> // nothrow
#include <cstring> // memcpy

using namespace std;

namespace read {

	// ################ FastqReader ################

	// ---------------- Public ----------------

	// Fastqファイルへの全てのアクセスを担う。
	FastqReader::FastqReader(uint8_t skipDepth) {
		skipDepth_ = skipDepth;
	}

	// 読みたいファイルを登録する。
	void FastqReader::setFiles(std::vector<std::string> normalFwdPaths, std::vector<std::string> normalRevPaths, std::vector<std::string> tumorFwdPaths, std::vector<std::string> tumorRevPaths) {
		normalFwdPaths_ = normalFwdPaths;
		normalRevPaths_ = normalRevPaths;
		tumorFwdPaths_ = tumorFwdPaths;
		tumorRevPaths_ = tumorRevPaths;
	}

	// シーケンシャルで読むときにターゲットとなるサンプルタイプを指定する。
	// getNextReadBlock()とペアで用いる。
	void FastqReader::setTarget(SampleType sampleType) {
		sampleType_ = sampleType;
		targetChanged_ = true;
		revStartID_ = 0;
	}

	// setTarget()で指定されたサンプルタイプのFastqを先頭から順に読み込み、リードブロックとしてメモリ上に圧縮整形して返す。
	// この関数は繰り返し呼ぶことで内部的にファイルポインタを自動で進めている。
	// ただしファイルポインタはsetTarget()によりリセットされる。
	// 指定サンプルタイプについて終端まで来たときは返り値でそれを知らせる。
	FastqReader::AccessResult FastqReader::getNextReadBlock(char * buff, int buffSize, int & buffUsedBytes, int & itemCount)
	{
		static vector<string> paths;
		static int pathIndex, pathRevIndex;
		static ifstream fastqFile;
		static ReadDirection direct;
		if (targetChanged_) {
			targetChanged_ = false;
			paths.clear();
			if (sampleType_ == SampleType::Tumor) {
				paths.reserve(tumorFwdPaths_.size() + tumorRevPaths_.size());
				// be sure to keep the order(Fwd,Fwd,,,Fwd,Rev,Rev,,,Rev)
				for (auto item : tumorFwdPaths_) paths.push_back(item);
				for (auto item : tumorRevPaths_) if (item != "") paths.push_back(item);
				pathRevIndex = (int)tumorFwdPaths_.size();
			}
			else {
				paths.reserve(normalFwdPaths_.size() + normalRevPaths_.size());
				for (auto item : normalFwdPaths_) paths.push_back(item);
				for (auto item : normalRevPaths_) if (item != "") paths.push_back(item);
				pathRevIndex = (int)normalFwdPaths_.size();
			}
			pathIndex = 0;
		}

		int readCount = 0;
		int headerIndex = 0;
		uint16_t bodyIndex = BlockReadCount * 2;

		while (pathIndex < (int)paths.size()) {
			if (!fastqFile.is_open()) {
				fastqFile.open(paths[pathIndex]);
				if (!fastqFile.is_open()) return FastqReader::AccessResult::OpenFailed;
				direct = (pathIndex >= pathRevIndex) ? ReadDirection::Reverse : ReadDirection::Forward;
			}
			string str;

			while (!fastqFile.eof())
			{
				// Seg1: ID
				do {
					std::getline(fastqFile, str);
				} while (str[0] != '@' && !fastqFile.eof());
				if (fastqFile.eof()) break;

				// Seg2: BASE (support multiline)
				int baseLineCount = 0; // Normaly 1, but if a read is too long and wrapped, larger than 1
				std::getline(fastqFile, str);
				do {
					baseLineCount++;
					if (trimBases(str, direct)) {
						int baseCount = (int)str.size();
						// avoid buffer overrun
						if (bodyIndex + ((baseCount + 3) >> 2) > buffSize) {
							fastqFile.close();
							return FastqReader::AccessResult::BufferDeficiency;
						}
						buff[headerIndex++] = (char)(bodyIndex >> 8);
						buff[headerIndex++] = (char)(bodyIndex & 0xFF);
						buff[bodyIndex++] = (char)((uint16_t)baseCount >> 8);
						buff[bodyIndex++] = (char)((uint16_t)baseCount & 0xFF);
						int base4Count = 0;
						char base4 = 0;
						if (direct == ReadDirection::Forward) {
							// Forward
							for (int i = 0; i < baseCount; i++) {
								base4 <<= 2;
								base4Count++;
								switch (str[i])
								{
								case 'A':
									base4 |= baseA;
									break;
								case 'C':
									base4 |= baseC;
									break;
								case 'G':
									base4 |= baseG;
									break;
								case 'T':
									base4 |= baseT;
									break;
								default:
									break;
								}
								if (base4Count == 4) {
									buff[bodyIndex++] = base4;
									base4Count = 0;
								}
							}
							revStartID_++;
						}
						else {
							// Reverse
							for (int i = baseCount - 1; i >= 0; i--) {
								base4 <<= 2;
								base4Count++;
								switch (str[i])
								{
								case 'A':
									base4 |= baseT;
									break;
								case 'C':
									base4 |= baseG;
									break;
								case 'G':
									base4 |= baseC;
									break;
								case 'T':
									base4 |= baseA;
									break;
								default:
									break;
								}
								if (base4Count == 4) {
									buff[bodyIndex++] = base4;
									base4Count = 0;
								}
							}
						}
						if (base4Count != 0) {
							buff[bodyIndex++] = base4 << ((4 - base4Count) * 2);
						}

						if (++readCount == BlockReadCount) {
							buffUsedBytes = bodyIndex;
							itemCount = readCount;
							for (int i = 1 + baseLineCount; i > 0; i--) {
								if (!fastqFile.eof()) {
									std::getline(fastqFile, str);
								}
							}
							return FastqReader::AccessResult::Success;
						}
					}
					// Seg3: + (or Seg2: BASE)
					if (fastqFile.eof()) break;
					std::getline(fastqFile, str);
				} while (str[0] != '+');
				if (fastqFile.eof()) break;

				// Seg4: QUALITY
				while (baseLineCount > 0 && !fastqFile.eof())
				{
					std::getline(fastqFile, str);
					baseLineCount--;
				}
			}
			fastqFile.close();
			pathIndex++;
		}

		if (readCount != 0) {
			// if final baseBin still not flushed, do them
			for (; headerIndex < BlockReadCount * 2;) {
				// fill unset header bytes with 0
				buff[headerIndex++] = 0;
				buff[headerIndex++] = 0;
			}
			buffUsedBytes = bodyIndex;
			itemCount = readCount;
			return FastqReader::AccessResult::Success;
		}
		else {
			return FastqReader::AccessResult::Finished;
		}
	}

	// ---------------- Private ----------------

	bool FastqReader::trimBases(std::string & baseStr, ReadDirection direct)
	{
		// getline() may left '\r' or '\n' at string end.
		if (baseStr[baseStr.size() - 1] == '\n') baseStr = baseStr.erase(baseStr.size() - 1);
		if (baseStr[baseStr.size() - 1] == '\r') baseStr = baseStr.erase(baseStr.size() - 1);

		// Read & Check a read from the first base till reaching the end or encountering a base except for ACGT.
		// If (checked base count > skipDepth_) Then append the read to list and exit.
		// If (checked base count <= skipDepth_ && Not reached the end still) Then reset checked base count and continue checking from this index.
		// Else exit(append failed).
		//
		// Note
		// Currently this method can create only one trimed read from one raw read.
		// For example, in case of this type of read below, first segment is proccessed properly while second segment is neglected.
		// read: [AGT...GC(longer than skipDepth_)]N[CCT...GA(longer than skipDepth_)]

		uint16_t count = 0;
		int idx;

		if (direct == ReadDirection::Forward) {
			idx = 0;
			for (; idx < (int)baseStr.size(); idx++) {
				// this code is much faster than " if (baseStr[idx] == 'A' || baseStr[idx] == 'C' || baseStr[idx] == 'G' || baseStr[idx] == 'T') "
				switch (baseStr[idx]) {
				case 'A':
				case 'C':
				case 'G':
				case 'T':
					count++;
					break;
				default:
					if (count > skipDepth_) goto OutOfForLoopFwd;
					count = 0;
					break;
				}
			}
		OutOfForLoopFwd:
			if (count <= skipDepth_) return false;
			baseStr = baseStr.substr(idx - count, count);
			return true;
		}
		else {
			idx = (int)baseStr.size() - 1;
			for (; idx >= 0; idx--) {
				switch (baseStr[idx]) {
				case 'A':
				case 'C':
				case 'G':
				case 'T':
					count++;
					break;
				default:
					if (count > skipDepth_) goto OutOfForLoopRev;
					count = 0;
					break;
				}
			}
		OutOfForLoopRev:
			if (count <= skipDepth_) return false;
			baseStr = baseStr.substr(idx + 1, count);
			return true;
		}
	}




	// ################ ReadCollection ################

	// ---------------- Public ----------------

	ReadCollection::ReadCollection(uint8_t skipDepth, AnalyzeDiv div, int sourceDivCount) {
		skipDepth_ = skipDepth;
		analyzeDiv_ = div;
		size_t pattern = size_t(1) << (int)div;
		prefixFwdCounts_.resize(pattern, 0);
		prefixRevCounts_.resize(pattern, 0);
		sourceDivCount_ = sourceDivCount;
		normalBlockOffset_ = 0;
		tumorBlockOffset_ = 0;

		// prepare reverse map
		reverseBasesMap_.resize(256);
		uint8_t forwardNot = 255;
		for (int i = 0; i < 256; i++) {
			uint8_t temp = ((forwardNot & 0b11001100) >> 2) | ((forwardNot & 0b00110011) << 2);
			reverseBasesMap_[i] = (uint8_t)(((temp & 0xF0) >> 4) | ((temp & 0x0F) << 4));
			forwardNot--;
		}
	}

	ReadCollection::~ReadCollection() {
		deleteReadOnMemory(SampleType::Normal);
		deleteReadOnMemory(SampleType::Tumor);
		if (normalTempPath_ != "") remove(normalTempPath_.c_str());
		if (tumorTempPath_ != "") remove(tumorTempPath_.c_str());
	}

	// ファイルを読み込む。
	// コンストラクタの次にまず最初に行うべき作業。
	bool ReadCollection::loadFiles(std::vector<std::string> normalFwdPaths, std::vector<std::string> normalRevPaths, std::vector<std::string> tumorFwdPaths, std::vector<std::string> tumorRevPaths, bool isStrandSpecific, std::string tempDir) {
		if (tempDir == "") {
			// if tempDir is unset then use fastq directory
			string path = normalFwdPaths[0];
			std::replace(path.begin(), path.end(), '\\', '/');
			tempDir = path.erase(path.find_last_of('/') + 1);
			// C:\temp のときに C:\tempFastq.binができてしまうのを要修正
		}

		isStrandSpecific_ = isStrandSpecific;
		if (!isStrandSpecific) {
			// ストランドスペシフィックではないのに順方向逆方向両方の入力があるときは、実質両者に違いはないので統合する
			if (normalRevPaths.size() > 0 && normalRevPaths[0] != "") {
				copy(normalRevPaths.begin(), normalRevPaths.end(), back_inserter(normalFwdPaths));
				normalRevPaths.clear();
			}
			if (tumorRevPaths.size() > 0 && tumorRevPaths[0] != "") {
				copy(tumorRevPaths.begin(), tumorRevPaths.end(), back_inserter(tumorFwdPaths));
				tumorRevPaths.clear();
			}
		}
		FastqReader fastqReader(skipDepth_);
		fastqReader.setFiles(normalFwdPaths, normalRevPaths, tumorFwdPaths, tumorRevPaths);
		bool res = true;
		res &= loadFiles(SampleType::Normal, &fastqReader, tempDir);
		res &= loadFiles(SampleType::Tumor, &fastqReader, tempDir);
		//if(res) countPrefixPatterns(); 

		return res;
	}

	// テンポラリファイル使用モードのときはloadFiles()ではメモリ上にリードが読み込まれていないのでloadFiles()に次いでこれを呼ぶ。
	// また同様に読み込むソースを切り替えたいときもこれを呼ぶ。この時、前回使用したソースの展開されているメモリは内部で自動解放される。
	// テンポラリファイルを使わないときは全くもって無用な関数。
	bool ReadCollection::loadTempFiles(SampleType sampleType, int sourceDivNum) {
		if (sourceDivCount_ == 1) return false;

		if (sampleType == SampleType::Tumor) {
			uint32_t len = ((uint32_t)tumorBlockFilePtrs_.size() - 1) / sourceDivCount_;
			uint32_t start = len * (sourceDivNum - 1);
			uint32_t end = sourceDivCount_ == sourceDivNum ? (uint32_t)tumorBlockFilePtrs_.size() - 2 : start + len - 1;
			deleteReadOnMemory(SampleType::Tumor);
			tumorBlockOffset_ = start;
			if (start > end) return true;
			return fileToMemory(tumorTempPath_, &tumorBlockFilePtrs_, start, end, &tumorReadBlocks_);
		}
		else {
			uint32_t len = ((uint32_t)normalBlockFilePtrs_.size() - 1) / sourceDivCount_;
			uint32_t start = len * (sourceDivNum - 1);
			uint32_t end = sourceDivCount_ == sourceDivNum ? (uint32_t)normalBlockFilePtrs_.size() - 2 : start + len - 1;
			deleteReadOnMemory(SampleType::Normal);
			normalBlockOffset_ = start;
			if (start > end) return true;
			return fileToMemory(normalTempPath_, &normalBlockFilePtrs_, start, end, &normalReadBlocks_);
		}
	}

	// メモリを解放する。
	// 過剰に呼んでも問題はないが、メモリ解放が必要なときは内部的にこれを呼んでいるはずなので(含デストラクタ)、外部からこれを呼ぶ必要はないと思われる。
	void ReadCollection::deleteReadOnMemory(SampleType sampleType) {
		if (sampleType == SampleType::Tumor) {
			for (uint8_t* item : tumorReadBlocks_) {
				delete[] item;
				item = nullptr;
			}
			tumorReadBlocks_.clear();
		}
		else {
			for (uint8_t* item : normalReadBlocks_) {
				delete[] item;
				item = nullptr;
			}
			normalReadBlocks_.clear();
		}
	}

	// Div16対応
	// メモリ上に展開されている全リードを探査して、(分割)解析時に必要なメモリ量を予め把握しておく。
	// リードをメモリに読み込んだら、これを1回呼んでから解析に移ること。
	void ReadCollection::countPrefixPatterns() {
		//if (analyzeDiv_ == AnalyzeDiv::x1) return;
		for (int i = 0; i < (int)prefixFwdCounts_.size(); i++) prefixFwdCounts_[i] = 0;
		for (int i = 0; i < (int)prefixRevCounts_.size(); i++) prefixRevCounts_[i] = 0;
		for (int k = 0; k < 2; k++) {
			vector<uint8_t*>* target = k == 0 ? &normalReadBlocks_ : &tumorReadBlocks_;
			uint32_t count = 0;
			int downShiftCount = 16 - (int)analyzeDiv_;
			int frameSize = max((int)analyzeDiv_ / 2 - 1, 0);
			for (size_t b = 0; b < target->size(); b++) {
				uint8_t* header = target->at(b);
				uint8_t* top = header;
				for (int i = 0; i < BlockReadCount; i++) {
					uint16_t offset = ((uint16_t)header[0] << 8) + header[1];
					if (offset == 0) break; // reached end
					header += 2;
					uint8_t* body = top + offset;
					int baseCount = ((uint16_t)body[0] << 8) + body[1];
					body += 2;
					uint16_t bases = (uint16_t)(*body++) << 6;
					for (int n = 0; n < baseCount - frameSize; n++) {
						bases <<= 2;
						if (n % 4 == 0) bases |= *body++;
						int prefixIndex = bases >> downShiftCount;
						if (n < baseCount - skipDepth_) {
							prefixFwdCounts_[prefixIndex]++;
						}
						if (!isStrandSpecific_ && n >= skipDepth_ - frameSize) {
							prefixRevCounts_[prefixIndex]++;
						}
					}
					count++;
				}
			}
			(k == 0 ? normalReadCount_ : tumorReadCount_) = count;
		}
	}

	// newIndex方式対応済み
	// Div16対応
	// 引数で渡されたPrefixCollectionを用いて、リードからPrefixオブジェクト群を作って登録する。
	// 以降の解析はPrefixCollectionで行う。
	bool ReadCollection::storePrefixUnits(prefix::PrefixCollection* prefixCol, uint16_t prefixPrefix, uint8_t length)
	{
		uint16_t prefixMask16 = uint16_t(0xFFFF) << (16 - (int)analyzeDiv_);
		uint16_t prefixPrefixFwdUpper16 = prefixPrefix << (16 - (int)analyzeDiv_); // ---A => A---
		uint16_t prefixPrefixRevUpper16 = reverse8Bases(prefixPrefix) & prefixMask16; // ---A => T---
		uint16_t prefixPrefixRev = prefixPrefixRevUpper16 >> (16 - (int)analyzeDiv_); // T--- => ---T
		if (length > 32) length = 32;
		prefixCol->deleteDictMemory();
		bool res = prefixCol->newDictMemory(prefixFwdCounts_[prefixPrefix] + prefixRevCounts_[prefixPrefixRev]);
		if (!res) return false;

		SampleType sampleTypes[2] = { SampleType::Normal, SampleType::Tumor };
		uint32_t readCounts[2] = { normalReadCount_, tumorReadCount_ };
		uint32_t blockOffset[2] = { normalBlockOffset_, tumorBlockOffset_ };
		//uint32_t revID[2] = { normalRevID_, tumorRevID_ };
		int frameSize = max((int)analyzeDiv_ / 2 - 1, 0);

		for (int k = 0; k < 2; k++) {
			SampleType sampleType = sampleTypes[k];
			uint32_t id = blockOffset[k] * BlockReadCount;
			uint32_t lastId = id + readCounts[k];

			uint16_t baseCount, bases;
			uint8_t* readPtr, *basePtr;
			while (id < lastId) {
				readPtr = fetchReadPtr(sampleType, id, baseCount);
				if (baseCount == 0) continue;
				basePtr = readPtr + 2;
				bases = (uint16_t)*basePtr++ << 6;
				for (uint16_t i = 0; i < baseCount - frameSize; i++) {
					bases <<= 2;
					if ((i & 0b11) == 0) bases |= *basePtr++;
					if (i < baseCount - skipDepth_) {
						if ((bases & prefixMask16) == prefixPrefixFwdUpper16) {
							prefixCol->append(fetchBases32AtPtr(readPtr, baseCount, i, length), length, id, i, sampleType, ReadDirection::Forward);
						}
					}
					if (!isStrandSpecific_ && i >= skipDepth_ - frameSize) {
						if ((bases & prefixMask16) == prefixPrefixRevUpper16) {
							uint16_t revi = baseCount - i - 1 - (uint16_t)frameSize;
							prefixCol->append(fetchReverseBases32AtPtr(readPtr, baseCount, revi, length), length, id, revi, sampleType, ReadDirection::Reverse);
						}
					}
				}
				++id;
			}
		}
		return true;
	}

	// newIndex方式対応済み
	// 指定サンプル・IDの指すリードの指定位置から指定長さ(<=32)ぶんの部分塩基列を[後ろ方向に or 前方向に逆相補鎖として]読み取り、32塩基/64bitフォーマットのui64で返す。
	uint64_t ReadCollection::fetchBases32At(SampleType sampleType, uint32_t id, uint16_t index, uint8_t length, ReadDirection direct) const
	{
		uint16_t baseCount;
		uint8_t* readPtr = fetchReadPtr(sampleType, id, baseCount);
		if (index >= baseCount) return 0;
		if (direct == ReadDirection::Forward) return fetchBases32AtPtr(readPtr, baseCount, index, length);
		else return fetchReverseBases32AtPtr(readPtr, baseCount, index, length);
	}

	// newIndex方式対応済み
	// 指定サンプル・IDの指すリードの指定位置から読める限りの部分塩基列(<=29)を[後ろ方向に or 前方向に逆相補鎖として]読み取り、29塩基/64bitフォーマットのui64で返す。
	// indexが範囲外のときは0(29base/64bitモードでは塩基なしを意味する)を返す。
	uint64_t ReadCollection::fetchBases29At(SampleType sampleType, uint32_t id, uint16_t index, ReadDirection direct) const
	{
		uint16_t baseCount;
		uint8_t* readPtr = fetchReadPtr(sampleType, id, baseCount) + 2;
		if (index >= baseCount) return 0;

		if (direct == ReadDirection::Forward) {
			uint64_t read = 0;
			int length = baseCount - index;
			if (length > 29) length = 29;
			int arrayIndex = index >> 2;
			int arrayEndIndex = (index + length - 1) >> 2;
			int downShiftCount = 6 - ((index + length - 1) & 0b11) * 2;
			int upShiftCount = (index & 0b11) * 2 + (7 + arrayIndex - arrayEndIndex) * 8 + downShiftCount;
			while (arrayIndex <= arrayEndIndex) {
				read <<= 8;
				read |= readPtr[arrayIndex]; 
				arrayIndex++;
			}
			return ((read >> downShiftCount) << upShiftCount) | length;
		}
		else {
			uint64_t read = 0;
			int length = baseCount - index;
			if (length > 29) length = 29;
			index = (uint16_t)(baseCount - index - 1);
			int arrayIndex = index >> 2;
			int arrayEndIndex = (index - length + 1) >> 2;
			int downShiftCount = ((index - length + 1) & 0b11) * 2;
			int upShiftCount = (6 - (index & 0b11) * 2) + (7 - arrayIndex + arrayEndIndex) * 8 + downShiftCount;
			while (arrayIndex >= arrayEndIndex) {
				read <<= 8;
				read |= reverse4Bases(readPtr[arrayIndex]);
				arrayIndex--;
			}
			return ((read >> downShiftCount) << upShiftCount) | length;
		}
	}

	// 指定サンプル・IDの指すリードを[そのまま or 逆相補鎖として]読み取り、Stringで返す。
	std::string ReadCollection::fetchReadString(SampleType sampleType, uint32_t id, bool usingTempFile, ReadDirection direct) const
	{
		uint16_t baseCount;
		uint8_t* readPtr;
		if (usingTempFile) {
			// read from file
			const vector<uint64_t>* const blockFilePtrs = sampleType == SampleType::Tumor ? &tumorBlockFilePtrs_ : &normalBlockFilePtrs_;
			ifstream tempFile(sampleType == SampleType::Tumor ? tumorTempPath_ : normalTempPath_, std::ios::binary);
			if (!tempFile.is_open()) return "";
			uint64_t top = blockFilePtrs->at(id >> BlockReadShiftCount);
			tempFile.seekg(top + 2 * (id & (BlockReadCount - 1)));
			uint8_t buff[2];
			tempFile.read(reinterpret_cast<char*>(buff), 2);
			tempFile.seekg(top + ((uint16_t)buff[0] << 8) + buff[1], ios_base::beg);
			tempFile.read(reinterpret_cast<char*>(buff), 2);
			baseCount = (uint16_t)(((uint16_t)buff[0] << 8) + buff[1]);
			if (baseCount == 0) return"";
			int readPtrSize = (baseCount + 3) >> 2;
			readPtr = new(nothrow) uint8_t[readPtrSize];
			if (readPtr == nullptr) return "";
			tempFile.read(reinterpret_cast<char*>(readPtr), readPtrSize);
		}
		else {
			// read from memory
			readPtr = fetchReadPtr(sampleType, id, baseCount) + 2;
			if (baseCount == 0) return "";
		}
		uint8_t base4 = 0;
		string str = "";
		if (direct == ReadDirection::Forward) {
			for (int n = 0; n < baseCount; n++) {
				if ((n & 0b11) == 0) {
					base4 = *readPtr++;
				}
				str += baseStrs[(base4 & 0b11000000) >> 6];
				base4 <<= 2;
			}
		}
		else {
			int n = baseCount - 1;
			readPtr += (n >> 2); // set ptr last of read
			int rem = n & 0b11;
			if (rem != 3) {
				// AAC- or AC-- or C---  (rem==2/1/0)
				base4 = reverse4Bases(*readPtr--);
				// -GTT or --GT or ---G  (rem==2/1/0)
				base4 <<= (3 - rem) * 2;
				// GTT- or GT-- or G---  (rem==2/1/0)
				for (int i = 0; i <= rem; i++) {
					str += baseStrs[(base4 & 0b11000000) >> 6];
					base4 <<= 2;
					n--;
				}
			}
			for (; n >= 0; n--) {
				if ((n & 0b11) == 3) {
					base4 = reverse4Bases(*readPtr--);
				}
				str += baseStrs[(base4 & 0b11000000) >> 6];
				base4 <<= 2;
			}
		}
		return str;
	}

	// 指定サンプル・IDの指すリードに含まれる塩基数を返す。
	uint16_t ReadCollection::getBaseCount(SampleType sampleType, uint32_t id) const
	{
		uint16_t baseCount;
		fetchReadPtr(sampleType, id, baseCount);
		return baseCount;
	}


	// ---------------- Private ----------------

	// 渡されたFastqReaderを使ってファイルからメモリ上にロードする。
	// サンプルタイプごとに1回ずつ呼ぶべし。
	// this method must be called once per normal or tumor
	bool ReadCollection::loadFiles(SampleType sampleType, FastqReader* fastqReader, std::string tempDir)
	{
		fastqReader->setTarget(sampleType);

		uint32_t readCount = 0;
		const int buffSize = BlockReadCount * (4 + 480 / 4);
		char* buff = new char[buffSize];
		int usedBytes, itemCount;

		if (sourceDivCount_ == 1) {
			// テンポラリファイルを使わない、早くて正確だがメモリをそこそこ使うモード(推奨)。
			// No temp file mode
			vector<uint8_t*>* blocks;
			if (sampleType == SampleType::Tumor) {
				blocks = &tumorReadBlocks_;
			}
			else {
				blocks = &normalReadBlocks_;
			}

			FastqReader::AccessResult res;
			while (true) {
				res = fastqReader->getNextReadBlock(buff, buffSize, usedBytes, itemCount);
				if (res == FastqReader::AccessResult::Success) {
					uint8_t* bin = new(nothrow) uint8_t[usedBytes];
					if (bin == nullptr) {
						// failed to alloc mem
						deleteReadOnMemory(sampleType);
						return false; 
					}
					memcpy(reinterpret_cast<char*>(bin), buff, (size_t)usedBytes);
					blocks->push_back(bin);
					readCount += itemCount;
				}
				else if (res == FastqReader::AccessResult::Finished) {
					(sampleType == SampleType::Tumor ? tumorRevID_ : normalRevID_) = fastqReader->getReverseStartAt();
					break;
				}
				else {
					return false;
				}
			}

			blocks->shrink_to_fit();
			if (sampleType == SampleType::Tumor) tumorReadCount_ = readCount;
			else normalReadCount_ = readCount;
			return true;
		}
		else {
			// テンポラリファイルを使う、メモリは節約できるが非常に低速で正確性にも欠けるモード(やむを得ない場合を除き非推奨)。
			// temp file mode
			string tempFileName = "FastqBinary";
			tempFileName += sampleType == SampleType::Tumor ? ".tumor.tmp" : ".normal.tmp";
			string binPath = tempDir + tempFileName;
			while (true)
			{
				// if binPath already exist then change binPath
				struct stat st;
				if (stat(binPath.c_str(), &st) == -1) break;
				else binPath = binPath + ".tmp";
			}

			vector<uint64_t>* blockFilePtrs;
			uint64_t blockFilePointer = 0;
			if (sampleType == SampleType::Tumor) {
				tumorTempPath_ = binPath;
				blockFilePtrs = &tumorBlockFilePtrs_;
			}
			else {
				normalTempPath_ = binPath;
				blockFilePtrs = &normalBlockFilePtrs_;
			}
			blockFilePtrs->clear();
			blockFilePtrs->reserve(100000);

			ofstream binFile(binPath, ios::out | ios::binary);
			// set larger buffer
			const int bufSize = 512;
			char bufo[bufSize]; // stack
			binFile.rdbuf()->pubsetbuf(bufo, bufSize);

			FastqReader::AccessResult res;
			while (true) {
				res = fastqReader->getNextReadBlock(buff, buffSize, usedBytes, itemCount);
				if (res == FastqReader::AccessResult::Success) {
					binFile.write(buff, usedBytes);
					blockFilePtrs->push_back(blockFilePointer);
					blockFilePointer += usedBytes;
					readCount += itemCount;
				}
				else if (res == FastqReader::AccessResult::Finished) {
					(sampleType == SampleType::Tumor ? tumorRevID_ : normalRevID_) = fastqReader->getReverseStartAt();
					break;
				}
				else {
					return false;
				}
			}

			binFile.close();
			blockFilePtrs->push_back(blockFilePointer); // set sentinel
			blockFilePtrs->shrink_to_fit();
			if (sampleType == SampleType::Tumor) tumorReadCount_ = readCount;
			else normalReadCount_ = readCount;
			return true;
		}
	}

	// 指定サンプル・IDのリードが含まれるブロックへのポインタを返す。
	uint8_t* ReadCollection::fetchBlockPtr(SampleType sampleType, uint32_t id) const
	{
		uint32_t blockID = id >> BlockReadShiftCount;
		if (sampleType == SampleType::Tumor) {
			return tumorReadBlocks_[blockID - tumorBlockOffset_];
		}
		else {
			return normalReadBlocks_[blockID - normalBlockOffset_];
		}
	}

	// 指定サンプル・IDのリードへのポインタを返す。
	// 引数にて該当リードの塩基数も返す。
	uint8_t* ReadCollection::fetchReadPtr(SampleType sampleType, uint32_t id, uint16_t & baseCount) const
	{
		uint8_t* target = fetchBlockPtr(sampleType, id);
		int i = (id & (uint32_t)(BlockReadCount - 1)) * 2;
		target += ((uint16_t)target[i] << 8) + target[i + 1];
		baseCount = (uint16_t)(((uint16_t)target[0] << 8) + target[1]);
		return target;
	}

	// 指定ポインタの指すリードの指定位置から前方向に指定長さ(<=32)ぶんの部分塩基列を読み取り、32塩基/64bitフォーマットのu64で返す。
	uint64_t ReadCollection::fetchBases32AtPtr(uint8_t* readPtr, uint16_t baseCount, uint16_t index, uint8_t length) const
	{
		if (index + length > baseCount) return 0;
		readPtr += 2;
		uint64_t read = 0;
		uint16_t arrayIndex = index >> 2; // bin array's index where arg index's pointing base exists
		uint16_t arrayEndIndex = (index + length - 1) >> 2; // bin array's index where value [index+length-1] pointing base exists
		while (arrayIndex < arrayEndIndex) {
			read <<= 8;
			read |= readPtr[arrayIndex]; 
			arrayIndex++;
		}
		// arrayIndex == arrayEndIndex
		int endBaseOffset = (((index + length - 1) & 0b11) + 1) * 2;
		read = read << endBaseOffset;
		read |= readPtr[arrayIndex] >> (8 - endBaseOffset);

		return read << (64 - length * 2);
	}

	// newIndex方式対応済み
	// 指定ポインタの指すリードの指定位置から後ろ方向に指定長さ(<=32)ぶんの部分塩基列を逆相補鎖として読み取り、32塩基/64bitフォーマットのu64で返す。
	uint64_t ReadCollection::fetchReverseBases32AtPtr(uint8_t* readPtr, uint16_t baseCount, uint16_t index, uint8_t length) const
	{
		if (index + length > baseCount) return 0;
		readPtr += 2;
		index = (uint16_t)(baseCount - index - 1);
		uint64_t read = 0;
		uint16_t arrayIndex = index >> 2; // bin array's index where arg index's pointing base exists
		uint16_t arrayEndIndex = (index - length + 1) >> 2; // bin array's index where value [index+length-1] pointing base exists
		while (arrayIndex > arrayEndIndex) {
			read <<= 8;
			read |= reverse4Bases(readPtr[arrayIndex]);
			arrayIndex--;
		}
		// arrayIndex == arrayEndIndex
		int endBaseOffset = (4 - ((index - length + 1) & 0b11)) * 2;
		read = read << endBaseOffset;
		read |= reverse4Bases(readPtr[arrayIndex]) >> (8 - endBaseOffset);

		return read << (64 - length * 2);
	}

	// テンポラリファイルとして書き出されているリードを、読み込む区間を指定してメモリ上にロードする
	bool ReadCollection::fileToMemory(std::string tmpPath, vector<uint64_t>* blockFilePtrs, size_t startIndex, size_t endIndex, vector<uint8_t*>* readBlocks) {
		ifstream tempFile(tmpPath, std::ios::binary);
		if (!tempFile.is_open()) return false;
		if (tempFile.eof()) return false; // reached eof unexpectedly
		while (startIndex <= endIndex) {
			int buffSize = (int)(blockFilePtrs->at(startIndex + 1) - blockFilePtrs->at(startIndex));
			uint8_t* buff = new(nothrow) uint8_t[buffSize]; // dont delete[] in this scope!
			if (buff == nullptr) return false; // failed to allocate memory
			tempFile.seekg(blockFilePtrs->at(startIndex), ios_base::beg);
			tempFile.read(reinterpret_cast<char*>(buff), buffSize);
			readBlocks->push_back(buff);
			startIndex++;
		}
		tempFile.close();
		return true;
	}



	// **************** DEBUG ****************

#ifndef NDEBUG

	// ---------------- Public ----------------

	string ReadCollection::_ui64toString(uint64_t val, bool as29baseMode) {
		const char baseStr[5] = { 'A', 'C', 'G', 'T', '-' };
		string res;
		if (as29baseMode) {
			int len = val & 0b00111111;
			for (int i = 62; i >= 6; i -= 2) {
				if (len > 0) {
					res += baseStr[(val >> i) & 0b11];
					len--;
				}
				else {
					res += baseStr[4];
				}
			}
		}
		else {
			for (int i = 62; i >= 0; i -= 2) {
				res += baseStr[(val >> i) & 0b11];
			}
		}
		return res;
	}

	void ReadCollection::_dump() {
		cout << "##### Normal #####\n";
		cout << "--- Blocks@Memory ---\n";
		_dumpBlocks(normalReadBlocks_, normalBlockOffset_);
		cout << "\n--- FilePtrs ---\n";
		_dumpFilePtrs(normalBlockFilePtrs_);
		cout << "\n##### Tumor #####\n";
		cout << "--- Blocks@Memory ---\n";
		_dumpBlocks(tumorReadBlocks_, tumorBlockOffset_);
		cout << "\n--- FilePtrs ---\n";
		_dumpFilePtrs(tumorBlockFilePtrs_);
		cout << "\n##### Normal&Tumor #####\n";
		cout << "Prefixs for AnalyzeDiv (includes reverse)\n";
		_dumpPrefixCounts();
	}

	// ---------------- Private ----------------

	void ReadCollection::_dumpBlocks(std::vector<uint8_t*> readBlocks, uint32_t blockOffset) {
		cout << "BlockCount:" << readBlocks.size() << "\n";
		for (int b = 0; b < (int)readBlocks.size(); b++) {
			cout << "\n BlockNo:" << b << "; Addr:0x" << hex << uppercase << (uint64_t)readBlocks[b] << dec << nouppercase << "\n";
			uint8_t* blockHeader = readBlocks[b];
			if (blockHeader == nullptr) {
				cout << "  NULL\n";
				continue;
			}
			/*int c = 0;
			for (; c < BlockReadCount; c++) {
				if (target[c * 2] == 0 && target[c * 2 + 1] == 0) break;
			}
			cout << "ReadCount@Block:" << c << "\n";*/
			for (int i = 0; i < BlockReadCount; i++) {
				uint16_t offset = ((uint16_t)blockHeader[i * 2] << 8) + (uint16_t)blockHeader[i * 2 + 1];
				if (offset == 0) break;
				uint8_t* readPtr = blockHeader + offset;
				uint16_t baseCount = (uint16_t)*readPtr++ << 8;
				baseCount += *readPtr++;
				cout << "  LocalID:" << i << "; GlobalID:" << (BlockReadCount * (blockOffset + b) + i) << "; Offset:" << offset << "; BaseCount:" << baseCount << "\n   ";
				uint8_t base4 = 0;
				for (int n = 0; n < baseCount; n++) {
					if (n % 4 == 0) {
						base4 = *readPtr++;
					}
					cout << baseStrs[(base4 & 0b11000000) >> 6];
					base4 <<= 2;
				}
				cout << "\n";
			}
		}
	}
	void ReadCollection::_dumpFilePtrs(std::vector<uint64_t> blockFilePtrs)
	{
		cout << "TotalBlockCount:" << blockFilePtrs.size() - 1 << "\n";
		for (uint64_t ptr : blockFilePtrs) {
			cout << " " << ptr << "\n";
		}
	}
	void ReadCollection::_dumpPrefixCounts()
	{
		auto dumpCount = [](vector<uint64_t>* prefixCounts) {
			int digits = 0, count = 0;
			while ((prefixCounts->size() >> (digits * 2)) > 1) digits++;
			for (uint64_t p : *prefixCounts) count += (int)p;
			cout << "AnalyzeDivCount:" << prefixCounts->size() << "; TotalItemCount:" << count << "\n";
			for (int i = 0; i < (int)prefixCounts->size(); i++) {
				cout << " ";
				if (digits >= 8) cout << baseStrs[(i >> 14) & 0b11];
				if (digits >= 7) cout << baseStrs[(i >> 12) & 0b11];
				if (digits >= 6) cout << baseStrs[(i >> 10) & 0b11];
				if (digits >= 5) cout << baseStrs[(i >> 8) & 0b11];
				if (digits >= 4) cout << baseStrs[(i >> 6) & 0b11];
				if (digits >= 3) cout << baseStrs[(i >> 4) & 0b11];
				if (digits >= 2) cout << baseStrs[(i >> 2) & 0b11];
				if (digits >= 1) cout << baseStrs[i & 0b11];
				else cout << "N/A";
				cout << ":" << prefixCounts->at(i) << "\n";
			}
		};
		cout << "<< Forward >>\n";
		dumpCount(&prefixFwdCounts_);
		cout << "<< Reverse >>\n";
		dumpCount(&prefixRevCounts_);
	}

#endif
}